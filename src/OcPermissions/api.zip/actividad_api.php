<?php
/**
 * actividad_api.php - Activities and Permissions Management API
 * Handles activity/module CRUD operations and their permissions
 * 
 * PHP 8.4
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/BaseAPI.php';

use API\BaseAPI;
use Ocallit\SqlEr\SqlExecutor;
use Exception;

class ActividadAPI extends BaseAPI {
    
    /**
     * Route to action handlers
     */
    protected function route(string $action): void {
        match($action) {
            'list' => $this->listActividades(),
            'get' => $this->getActividad(),
            'save' => $this->save(),
            'delete' => $this->delete(),
            default => throw new Exception("Unknown action: {$action}", 400)
        };
    }
    
    /**
     * List all activities with their permissions
     */
    private function listActividades(): void {
        // Get all activities
        $actividades = $this->sql->array(
            "SELECT 
                a.actividad_id,
                a.actividad,
                a.descripcion,
                a.registrado_el,
                a.registrado_por
             FROM actividad a
             ORDER BY a.actividad"
        );
        
        // Get all permissions for all activities
        $permisos = $this->sql->array(
            "SELECT 
                ap.actividad_permiso_id,
                ap.actividad_id,
                ap.permiso,
                ap.etiqueta,
                ap.registrado_el,
                ap.registrado_por
             FROM actividad_permiso ap
             ORDER BY ap.actividad_id, ap.permiso"
        );
        
        // Group permissions by activity
        $permisosByActividad = [];
        foreach ($permisos as $permiso) {
            $actividadId = $permiso['actividad_id'];
            if (!isset($permisosByActividad[$actividadId])) {
                $permisosByActividad[$actividadId] = [];
            }
            $permisosByActividad[$actividadId][] = $permiso;
        }
        
        // Add permissions array to each activity
        foreach ($actividades as &$actividad) {
            $actividadId = $actividad['actividad_id'];
            $actividad['permisos'] = $permisosByActividad[$actividadId] ?? [];
        }
        unset($actividad);
        
        $this->sendSuccess($actividades);
    }
    
    /**
     * Get a single activity with its permissions
     */
    private function getActividad(): void {
        $this->requireFields(['actividad_id']);
        
        $actividadId = (int)$this->request['actividad_id'];
        
        // Get activity
        $actividad = $this->sql->row(
            "SELECT 
                a.actividad_id,
                a.actividad,
                a.descripcion,
                a.registrado_el,
                a.registrado_por
             FROM actividad a
             WHERE a.actividad_id = ?",
            [$actividadId]
        );
        
        if (empty($actividad)) {
            throw new Exception("Activity ID {$actividadId} not found", 404);
        }
        
        // Get permissions for this activity
        $permisos = $this->sql->array(
            "SELECT 
                ap.actividad_permiso_id,
                ap.actividad_id,
                ap.permiso,
                ap.etiqueta,
                ap.registrado_el,
                ap.registrado_por
             FROM actividad_permiso ap
             WHERE ap.actividad_id = ?
             ORDER BY ap.permiso",
            [$actividadId]
        );
        
        $actividad['permisos'] = $permisos;
        
        $this->sendSuccess($actividad);
    }
    
    /**
     * Save activity (create or update) with its permissions
     */
    private function save(): void {
        $this->requirePermission('actividades.editar');
        
        $actividadData = $this->request;
        
        // Validate required fields
        if (empty($actividadData['actividad'])) {
            throw new Exception('Activity name is required', 400);
        }
        
        try {
            $this->sql->begin('Save actividad');
            
            $actividadId = (int)($actividadData['actividad_id'] ?? 0);
            
            if ($actividadId > 0) {
                // Update existing activity
                $this->updateActividad($actividadData);
            } else {
                // Create new activity
                $actividadId = $this->createActividad($actividadData);
            }
            
            // Update permissions
            if (isset($actividadData['permisos']) && is_array($actividadData['permisos'])) {
                $this->updatePermisos($actividadId, $actividadData['permisos']);
            }
            
            $this->sql->commit('Save actividad');
            
            // Return the updated activity
            $this->request['actividad_id'] = $actividadId;
            $this->getActividad();
            
        } catch (Exception $e) {
            $this->sql->rollback('Save actividad error');
            throw $e;
        }
    }
    
    /**
     * Create new activity
     */
    private function createActividad(array $data): int {
        // Check if activity name already exists
        $exists = $this->sql->firstValue(
            "SELECT COUNT(*) FROM actividad WHERE actividad = ?",
            [$data['actividad']]
        );
        
        if ($exists > 0) {
            throw new Exception("Activity '{$data['actividad']}' already exists", 400);
        }
        
        $now = date('Y-m-d H:i:s');
        $currentUser = $this->getCurrentUserNick();
        
        // Prepare insert data
        $insertData = [
            'actividad' => $this->sanitizeString($data['actividad']),
            'descripcion' => $this->sanitizeString($data['descripcion'] ?? ''),
            'registrado_el' => $now,
            'registrado_por' => $currentUser
        ];
        
        // Build and execute insert
        $insert = $this->qb->insert('actividad', $insertData);
        $this->sql->query($insert['query'], $insert['parameters']);
        
        return $this->sql->last_insert_id();
    }
    
    /**
     * Update existing activity
     */
    private function updateActividad(array $data): void {
        $actividadId = (int)$data['actividad_id'];
        
        // Check if activity exists
        $exists = $this->sql->firstValue(
            "SELECT COUNT(*) FROM actividad WHERE actividad_id = ?",
            [$actividadId]
        );
        
        if (!$exists) {
            throw new Exception("Activity ID {$actividadId} not found", 404);
        }
        
        // Check if new name conflicts with existing activity
        if (!empty($data['actividad'])) {
            $conflict = $this->sql->firstValue(
                "SELECT COUNT(*) FROM actividad WHERE actividad = ? AND actividad_id != ?",
                [$data['actividad'], $actividadId]
            );
            
            if ($conflict > 0) {
                throw new Exception("Activity name '{$data['actividad']}' already exists", 400);
            }
        }
        
        // Prepare update data
        $updateData = [
            'actividad' => $this->sanitizeString($data['actividad']),
            'descripcion' => $this->sanitizeString($data['descripcion'] ?? '')
        ];
        
        // Build and execute update
        $update = $this->qb->update(
            'actividad',
            $updateData,
            ['actividad_id' => $actividadId]
        );
        
        $this->sql->query($update['query'], $update['parameters']);
    }
    
    /**
     * Update permissions for an activity
     */
    private function updatePermisos(int $actividadId, array $permisos): void {
        $now = date('Y-m-d H:i:s');
        $currentUser = $this->getCurrentUserNick();
        
        // Get existing permission IDs
        $existingIds = $this->sql->vector(
            "SELECT actividad_permiso_id FROM actividad_permiso WHERE actividad_id = ?",
            [$actividadId]
        );
        
        $processedIds = [];
        
        // Process each permission
        foreach ($permisos as $permiso) {
            $permisoId = (int)($permiso['actividad_permiso_id'] ?? 0);
            
            if ($permisoId > 0 && in_array($permisoId, $existingIds)) {
                // Update existing permission
                $this->updatePermiso($permisoId, $permiso);
                $processedIds[] = $permisoId;
            } else {
                // Create new permission
                $newPermisoId = $this->createPermiso($actividadId, $permiso, $now, $currentUser);
                $processedIds[] = $newPermisoId;
            }
        }
        
        // Delete permissions that were removed
        $toDelete = array_diff($existingIds, $processedIds);
        if (!empty($toDelete)) {
            $placeholders = implode(',', array_fill(0, count($toDelete), '?'));
            $this->sql->query(
                "DELETE FROM actividad_permiso WHERE actividad_permiso_id IN ({$placeholders})",
                array_values($toDelete)
            );
        }
    }
    
    /**
     * Create new permission
     */
    private function createPermiso(int $actividadId, array $permiso, string $now, string $currentUser): int {
        // Validate required fields
        if (empty($permiso['permiso'])) {
            throw new Exception('Permission code is required', 400);
        }
        if (empty($permiso['etiqueta'])) {
            throw new Exception('Permission label is required', 400);
        }
        
        // Check for duplicate permission code in this activity
        $exists = $this->sql->firstValue(
            "SELECT COUNT(*) FROM actividad_permiso 
             WHERE actividad_id = ? AND permiso = ?",
            [$actividadId, $permiso['permiso']]
        );
        
        if ($exists > 0) {
            throw new Exception("Permission '{$permiso['permiso']}' already exists for this activity", 400);
        }
        
        // Check for duplicate label in this activity
        $labelExists = $this->sql->firstValue(
            "SELECT COUNT(*) FROM actividad_permiso 
             WHERE actividad_id = ? AND etiqueta = ?",
            [$actividadId, $permiso['etiqueta']]
        );
        
        if ($labelExists > 0) {
            throw new Exception("Label '{$permiso['etiqueta']}' already exists for this activity", 400);
        }
        
        // Insert permission
        $insertData = [
            'actividad_id' => $actividadId,
            'permiso' => $this->sanitizeString($permiso['permiso']),
            'etiqueta' => $this->sanitizeString($permiso['etiqueta']),
            'registrado_el' => $now,
            'registrado_por' => $currentUser
        ];
        
        $insert = $this->qb->insert('actividad_permiso', $insertData);
        $this->sql->query($insert['query'], $insert['parameters']);
        
        return $this->sql->last_insert_id();
    }
    
    /**
     * Update existing permission
     */
    private function updatePermiso(int $permisoId, array $permiso): void {
        // Get activity_id for this permission
        $actividadId = $this->sql->firstValue(
            "SELECT actividad_id FROM actividad_permiso WHERE actividad_permiso_id = ?",
            [$permisoId]
        );
        
        if (!$actividadId) {
            throw new Exception("Permission ID {$permisoId} not found", 404);
        }
        
        // Check for duplicate permission code
        if (!empty($permiso['permiso'])) {
            $conflict = $this->sql->firstValue(
                "SELECT COUNT(*) FROM actividad_permiso 
                 WHERE actividad_id = ? AND permiso = ? AND actividad_permiso_id != ?",
                [$actividadId, $permiso['permiso'], $permisoId]
            );
            
            if ($conflict > 0) {
                throw new Exception("Permission '{$permiso['permiso']}' already exists", 400);
            }
        }
        
        // Check for duplicate label
        if (!empty($permiso['etiqueta'])) {
            $labelConflict = $this->sql->firstValue(
                "SELECT COUNT(*) FROM actividad_permiso 
                 WHERE actividad_id = ? AND etiqueta = ? AND actividad_permiso_id != ?",
                [$actividadId, $permiso['etiqueta'], $permisoId]
            );
            
            if ($labelConflict > 0) {
                throw new Exception("Label '{$permiso['etiqueta']}' already exists", 400);
            }
        }
        
        // Update permission
        $updateData = [
            'permiso' => $this->sanitizeString($permiso['permiso']),
            'etiqueta' => $this->sanitizeString($permiso['etiqueta'])
        ];
        
        $update = $this->qb->update(
            'actividad_permiso',
            $updateData,
            ['actividad_permiso_id' => $permisoId]
        );
        
        $this->sql->query($update['query'], $update['parameters']);
    }
    
    /**
     * Delete an activity and all its permissions
     */
    private function delete(): void {
        $this->requireFields(['actividad_id']);
        $this->requirePermission('actividades.eliminar');
        
        $actividadId = (int)$this->request['actividad_id'];
        
        // Check if activity exists
        $exists = $this->sql->firstValue(
            "SELECT COUNT(*) FROM actividad WHERE actividad_id = ?",
            [$actividadId]
        );
        
        if (!$exists) {
            throw new Exception("Activity ID {$actividadId} not found", 404);
        }
        
        // Check if any roles are using permissions from this activity
        $rolesUsing = $this->sql->firstValue(
            "SELECT COUNT(DISTINCT rap.rol_id)
             FROM rol_actividad_permiso rap
             JOIN actividad_permiso ap ON rap.actividad_permiso_id = ap.actividad_permiso_id
             WHERE ap.actividad_id = ?",
            [$actividadId]
        );
        
        if ($rolesUsing > 0) {
            throw new Exception(
                "Cannot delete activity: {$rolesUsing} role(s) are using permissions from this activity. " .
                "Please remove the permission assignments first.",
                400
            );
        }
        
        try {
            $this->sql->begin('Delete actividad');
            
            // Delete all permissions for this activity (CASCADE will handle this, but being explicit)
            $this->sql->query(
                "DELETE FROM actividad_permiso WHERE actividad_id = ?",
                [$actividadId]
            );
            
            // Delete the activity
            $this->sql->query(
                "DELETE FROM actividad WHERE actividad_id = ?",
                [$actividadId]
            );
            
            $this->sql->commit('Delete actividad');
            
            $this->sendSuccess(null, "Activity deleted successfully");
            
        } catch (Exception $e) {
            $this->sql->rollback('Delete actividad error');
            throw $e;
        }
    }
}

// Initialize and handle request
try {
    // Get database connection from config
    $sql = getSqlExecutor();
    
    // Create API instance and handle request
    $api = new ActividadAPI($sql, $config);
    $api->handle();
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'data' => null
    ], JSON_UNESCAPED_UNICODE);
}
