<?php
/**
 * asignar_permisos_api.php - Assign Permissions to Roles API
 * Handles assignment of activity permissions to roles
 * 
 * PHP 8.4
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/BaseAPI.php';

use API\BaseAPI;
use Ocallit\SqlEr\SqlExecutor;
use Exception;

class AsignarPermisosAPI extends BaseAPI {
    
    /**
     * Route to action handlers
     */
    protected function route(string $action): void {
        match($action) {
            'load' => $this->load(),
            'save' => $this->save(),
            default => throw new Exception("Unknown action: {$action}", 400)
        };
    }
    
    /**
     * Load all data needed for permission assignment
     * Returns: roles, activities, activity_permissions, and current assignments
     */
    private function load(): void {
        // Get all roles
        $roles = $this->sql->array(
            "SELECT 
                r.rol_id,
                r.rol,
                r.descripcion
             FROM rol r
             ORDER BY r.rol"
        );
        
        // Get all activities
        $actividades = $this->sql->array(
            "SELECT 
                a.actividad_id,
                a.actividad,
                a.descripcion
             FROM actividad a
             ORDER BY a.actividad"
        );
        
        // Get all activity permissions
        $actividad_permisos = $this->sql->array(
            "SELECT 
                ap.actividad_permiso_id,
                ap.actividad_id,
                ap.permiso,
                ap.etiqueta
             FROM actividad_permiso ap
             ORDER BY ap.actividad_id, ap.permiso"
        );
        
        // Get current assignments (which permissions are assigned to which roles)
        // We'll return this as a nested structure: {rol_id: [permiso_id1, permiso_id2, ...]}
        $assignmentsRaw = $this->sql->array(
            "SELECT 
                rap.rol_id,
                rap.actividad_permiso_id
             FROM rol_actividad_permiso rap
             ORDER BY rap.rol_id, rap.actividad_permiso_id"
        );
        
        // Convert to nested structure
        $asignaciones = [];
        foreach ($assignmentsRaw as $assignment) {
            $rolId = (int)$assignment['rol_id'];
            $permisoId = (int)$assignment['actividad_permiso_id'];
            
            if (!isset($asignaciones[$rolId])) {
                $asignaciones[$rolId] = [];
            }
            $asignaciones[$rolId][] = $permisoId;
        }
        
        // Also prepare rowPairs for the grid (all combinations of rol and actividad)
        $rowPairs = [];
        foreach ($roles as $rol) {
            foreach ($actividades as $actividad) {
                $rowPairs[] = [
                    'rol_id' => (int)$rol['rol_id'],
                    'actividad_id' => (int)$actividad['actividad_id']
                ];
            }
        }
        
        $this->sendSuccess([
            'roles' => $roles,
            'actividades' => $actividades,
            'actividad_permisos' => $actividad_permisos,
            'asignaciones' => $asignaciones,
            'rowPairs' => $rowPairs
        ]);
    }
    
    /**
     * Save permission assignments
     * Expects data with asignaciones structure: {rol_id: [permiso_id1, permiso_id2, ...]}
     */
    private function save(): void {
        $this->requireFields(['data']);
        $this->requirePermission('permisos.asignar');
        
        $data = $this->request['data'];
        
        // Validate data structure
        if (!isset($data['asignaciones']) || !is_array($data['asignaciones'])) {
            throw new Exception('Invalid data structure: asignaciones required', 400);
        }
        
        try {
            $this->sql->begin('Save permission assignments');
            
            $asignaciones = $data['asignaciones'];
            
            // Process assignments for each role
            foreach ($asignaciones as $rolId => $permisoIds) {
                $rolId = (int)$rolId;
                
                // Validate role exists
                $roleExists = $this->sql->firstValue(
                    "SELECT COUNT(*) FROM rol WHERE rol_id = ?",
                    [$rolId]
                );
                
                if (!$roleExists) {
                    throw new Exception("Role ID {$rolId} not found", 404);
                }
                
                // Update assignments for this role
                $this->updateRolePermissions($rolId, $permisoIds);
            }
            
            // Also handle roles that have no permissions (empty arrays or not in asignaciones)
            // Get all role IDs
            $allRoleIds = $this->sql->vector("SELECT rol_id FROM rol");
            
            foreach ($allRoleIds as $rolId) {
                if (!isset($asignaciones[$rolId])) {
                    // Role has no permissions assigned, clear all
                    $this->updateRolePermissions($rolId, []);
                }
            }
            
            $this->sql->commit('Save permission assignments');
            
            // Return updated data
            $this->load();
            
        } catch (Exception $e) {
            $this->sql->rollback('Save permission assignments error');
            throw $e;
        }
    }
    
    /**
     * Update permissions for a specific role
     * 
     * @param int $rolId Role ID
     * @param array $permisoIds Array of permission IDs to assign
     */
    private function updateRolePermissions(int $rolId, array $permisoIds): void {
        $now = date('Y-m-d H:i:s');
        $currentUser = $this->getCurrentUserNick();
        
        // Clean the permission IDs array (ensure they're integers and positive)
        $permisoIds = array_filter(
            array_map('intval', $permisoIds),
            fn($id) => $id > 0
        );
        
        // Remove duplicates
        $permisoIds = array_unique($permisoIds);
        
        // Validate that all permission IDs exist
        if (!empty($permisoIds)) {
            $placeholders = implode(',', array_fill(0, count($permisoIds), '?'));
            $validCount = $this->sql->firstValue(
                "SELECT COUNT(*) FROM actividad_permiso WHERE actividad_permiso_id IN ({$placeholders})",
                array_values($permisoIds)
            );
            
            if ($validCount != count($permisoIds)) {
                throw new Exception("One or more permission IDs are invalid", 400);
            }
        }
        
        // Delete all current permissions for this role
        $this->sql->query(
            "DELETE FROM rol_actividad_permiso WHERE rol_id = ?",
            [$rolId]
        );
        
        // Insert new permissions
        if (!empty($permisoIds)) {
            // Use batch insert for better performance
            $values = [];
            $params = [];
            
            foreach ($permisoIds as $permisoId) {
                $values[] = "(?, ?, ?, ?)";
                $params[] = $rolId;
                $params[] = $permisoId;
                $params[] = $now;
                $params[] = $currentUser;
            }
            
            $query = "INSERT INTO rol_actividad_permiso 
                      (rol_id, actividad_permiso_id, registrado_el, registrado_por) 
                      VALUES " . implode(', ', $values);
            
            $this->sql->query($query, $params);
        }
    }
}

// Initialize and handle request
try {
    // Get database connection from config
    $sql = getSqlExecutor();
    
    // Create API instance and handle request
    $api = new AsignarPermisosAPI($sql, $config);
    $api->handle();
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'data' => null
    ], JSON_UNESCAPED_UNICODE);
}
