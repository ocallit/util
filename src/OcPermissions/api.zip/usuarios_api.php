<?php
/**
 * usuarios_api.php - User Management API
 * Handles user CRUD operations, role assignments
 * 
 * PHP 8.4
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/BaseAPI.php';

use API\BaseAPI;
use Ocallit\SqlEr\SqlExecutor;
use Exception;

class UsuariosAPI extends BaseAPI {
    
    /**
     * Route to action handlers
     */
    protected function route(string $action): void {
        match($action) {
            'load' => $this->load(),
            'save' => $this->save(),
            default => throw new Exception("Unknown action: {$action}", 400)
        };
    }
    
    /**
     * Load all users with their roles
     */
    private function load(): void {
        // Get all users
        $usuarios = $this->sql->array(
            "SELECT 
                u.usuario_id,
                u.nick,
                u.nombre,
                u.email,
                u.cel,
                u.estatus,
                u.nota,
                u.password_forza_cambio,
                u.password_caducidad_dias,
                u.password_ultimo_cambio,
                u.ultimo_login,
                u.creado_el,
                u.creado_por,
                u.ultimo_cambio_el,
                u.ultimo_cambio_por
             FROM usuario u
             ORDER BY u.nombre"
        );
        
        // Get all roles (for dropdown)
        $roles = $this->sql->array(
            "SELECT rol_id, rol 
             FROM rol 
             ORDER BY rol"
        );
        
        // Get role assignments
        $rol_usuario = $this->sql->array(
            "SELECT rol_id, usuario_id 
             FROM rol_usuario"
        );
        
        $this->sendSuccess([
            'usuarios' => $usuarios,
            'roles' => $roles,
            'rol_usuario' => $rol_usuario
        ]);
    }
    
    /**
     * Save user data (create or update)
     * Also handles role assignments
     */
    private function save(): void {
        $this->requireFields(['data']);
        $this->requirePermission('usuarios.editar');
        
        $data = $this->request['data'];
        
        // Validate data structure
        if (!isset($data['usuarios']) || !is_array($data['usuarios'])) {
            throw new Exception('Invalid data structure: usuarios array required', 400);
        }
        
        if (!isset($data['rol_usuario']) || !is_array($data['rol_usuario'])) {
            throw new Exception('Invalid data structure: rol_usuario array required', 400);
        }
        
        try {
            $this->sql->begin('Save usuarios');
            
            // Process each user
            foreach ($data['usuarios'] as $usuario) {
                if (isset($usuario['usuario_id']) && $usuario['usuario_id'] > 0) {
                    // Update existing user
                    $this->updateUsuario($usuario);
                } else {
                    // Create new user
                    $this->createUsuario($usuario);
                }
            }
            
            // Update role assignments
            $this->updateRoleAssignments($data['usuarios'], $data['rol_usuario']);
            
            $this->sql->commit('Save usuarios');
            
            // Return updated data
            $this->load();
            
        } catch (Exception $e) {
            $this->sql->rollback('Save usuarios error');
            throw $e;
        }
    }
    
    /**
     * Create new user
     */
    private function createUsuario(array $usuario): int {
        // Validate required fields
        if (empty($usuario['nick'])) {
            throw new Exception('Nick is required', 400);
        }
        if (empty($usuario['nombre'])) {
            throw new Exception('Nombre is required', 400);
        }
        
        // Check if nick already exists
        $exists = $this->sql->firstValue(
            "SELECT COUNT(*) FROM usuario WHERE nick = ?",
            [$usuario['nick']]
        );
        
        if ($exists > 0) {
            throw new Exception("Nick '{$usuario['nick']}' already exists", 400);
        }
        
        $now = date('Y-m-d H:i:s');
        $currentUser = $this->getCurrentUserNick();
        
        // Prepare insert data
        $insertData = [
            'nick' => $this->sanitizeString($usuario['nick']),
            'nombre' => $this->sanitizeString($usuario['nombre']),
            'email' => $this->sanitizeString($usuario['email'] ?? ''),
            'cel' => $this->sanitizeString($usuario['cel'] ?? ''),
            'estatus' => $usuario['estatus'] ?? 'Puede Login',
            'nota' => $this->sanitizeString($usuario['nota'] ?? ''),
            'password_forza_cambio' => $usuario['password_forza_cambio'] ?? 'Si',
            'password_caducidad_dias' => (int)($usuario['password_caducidad_dias'] ?? 90),
            'password_ultimo_cambio' => $now,
            'creado_el' => $now,
            'creado_por' => $currentUser,
            'ultimo_cambio_el' => $now,
            'ultimo_cambio_por' => $currentUser
        ];
        
        // Handle password - should be hashed
        if (!empty($usuario['password'])) {
            $insertData['password'] = password_hash($usuario['password'], PASSWORD_DEFAULT);
        } else {
            throw new Exception('Password is required for new users', 400);
        }
        
        // Build and execute insert
        $insert = $this->qb->insert('usuario', $insertData);
        $this->sql->query($insert['query'], $insert['parameters']);
        
        return $this->sql->last_insert_id();
    }
    
    /**
     * Update existing user
     */
    private function updateUsuario(array $usuario): void {
        $usuarioId = (int)$usuario['usuario_id'];
        
        // Check if user exists
        $exists = $this->sql->firstValue(
            "SELECT COUNT(*) FROM usuario WHERE usuario_id = ?",
            [$usuarioId]
        );
        
        if (!$exists) {
            throw new Exception("User ID {$usuarioId} not found", 404);
        }
        
        $now = date('Y-m-d H:i:s');
        $currentUser = $this->getCurrentUserNick();
        
        // Prepare update data
        $updateData = [
            'nick' => $this->sanitizeString($usuario['nick']),
            'nombre' => $this->sanitizeString($usuario['nombre']),
            'email' => $this->sanitizeString($usuario['email'] ?? ''),
            'cel' => $this->sanitizeString($usuario['cel'] ?? ''),
            'estatus' => $usuario['estatus'] ?? 'Puede Login',
            'nota' => $this->sanitizeString($usuario['nota'] ?? ''),
            'password_forza_cambio' => $usuario['password_forza_cambio'] ?? 'No',
            'password_caducidad_dias' => (int)($usuario['password_caducidad_dias'] ?? 90),
            'ultimo_cambio_el' => $now,
            'ultimo_cambio_por' => $currentUser
        ];
        
        // Handle password update if provided
        if (!empty($usuario['password'])) {
            $updateData['password'] = password_hash($usuario['password'], PASSWORD_DEFAULT);
            $updateData['password_ultimo_cambio'] = $now;
        }
        
        // Build and execute update
        $update = $this->qb->update(
            'usuario',
            $updateData,
            ['usuario_id' => $usuarioId]
        );
        
        $this->sql->query($update['query'], $update['parameters']);
    }
    
    /**
     * Update role assignments for users
     */
    private function updateRoleAssignments(array $usuarios, array $rolUsuarios): void {
        $currentUser = $this->getCurrentUserNick();
        $now = date('Y-m-d H:i:s');
        
        // Get user IDs from the usuarios array
        $userIds = array_filter(array_map(fn($u) => (int)($u['usuario_id'] ?? 0), $usuarios));
        
        if (empty($userIds)) {
            return;
        }
        
        // Delete existing role assignments for these users
        $placeholders = implode(',', array_fill(0, count($userIds), '?'));
        $this->sql->query(
            "DELETE FROM rol_usuario WHERE usuario_id IN ({$placeholders})",
            $userIds
        );
        
        // Insert new role assignments
        foreach ($rolUsuarios as $assignment) {
            $rolId = (int)($assignment['rol_id'] ?? 0);
            $usuarioId = (int)($assignment['usuario_id'] ?? 0);
            
            if ($rolId <= 0 || $usuarioId <= 0) {
                continue;
            }
            
            // Only process if usuario_id is in our list
            if (!in_array($usuarioId, $userIds)) {
                continue;
            }
            
            // Check if role exists
            $roleExists = $this->sql->firstValue(
                "SELECT COUNT(*) FROM rol WHERE rol_id = ?",
                [$rolId]
            );
            
            if (!$roleExists) {
                continue;
            }
            
            // Insert assignment
            $this->sql->query(
                "INSERT INTO rol_usuario (rol_id, usuario_id, registrado_el, registrado_por) 
                 VALUES (?, ?, ?, ?)",
                [$rolId, $usuarioId, $now, $currentUser]
            );
        }
    }
}

// Initialize and handle request
try {
    // Get database connection from config
    $sql = getSqlExecutor();
    
    // Create API instance and handle request
    $api = new UsuariosAPI($sql, $config);
    $api->handle();
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'data' => null
    ], JSON_UNESCAPED_UNICODE);
}
