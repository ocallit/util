<?php
/**
 * roles_api.php - Roles Management API
 * Handles role CRUD operations and user assignments
 * 
 * PHP 8.4
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/BaseAPI.php';

use API\BaseAPI;
use Ocallit\SqlEr\SqlExecutor;
use Exception;

class RolesAPI extends BaseAPI {
    
    /**
     * Route to action handlers
     */
    protected function route(string $action): void {
        match($action) {
            'load' => $this->load(),
            'save' => $this->save(),
            default => throw new Exception("Unknown action: {$action}", 400)
        };
    }
    
    /**
     * Load all roles with assigned users
     */
    private function load(): void {
        // Get all roles
        $roles = $this->sql->array(
            "SELECT 
                r.rol_id,
                r.rol,
                r.descripcion,
                r.registrado_el,
                r.registrado_por
             FROM rol r
             ORDER BY r.rol"
        );
        
        // Get all users (for dropdown and display)
        $usuarios = $this->sql->array(
            "SELECT 
                u.usuario_id,
                u.nick,
                u.nombre
             FROM usuario u
             ORDER BY u.nombre"
        );
        
        // Get role-user assignments
        $rol_usuario = $this->sql->array(
            "SELECT rol_id, usuario_id 
             FROM rol_usuario
             ORDER BY rol_id, usuario_id"
        );
        
        $this->sendSuccess([
            'roles' => $roles,
            'usuarios' => $usuarios,
            'rol_usuario' => $rol_usuario
        ]);
    }
    
    /**
     * Save role data (create or update) and user assignments
     */
    private function save(): void {
        $this->requireFields(['data']);
        $this->requirePermission('roles.editar');
        
        $data = $this->request['data'];
        
        // Validate data structure
        if (!isset($data['roles']) || !is_array($data['roles'])) {
            throw new Exception('Invalid data structure: roles array required', 400);
        }
        
        if (!isset($data['rol_usuario']) || !is_array($data['rol_usuario'])) {
            throw new Exception('Invalid data structure: rol_usuario array required', 400);
        }
        
        try {
            $this->sql->begin('Save roles');
            
            // Process each role
            $processedRoleIds = [];
            foreach ($data['roles'] as $rol) {
                if (isset($rol['rol_id']) && $rol['rol_id'] > 0) {
                    // Update existing role
                    $this->updateRol($rol);
                    $processedRoleIds[] = (int)$rol['rol_id'];
                } else {
                    // Create new role
                    $newRolId = $this->createRol($rol);
                    $processedRoleIds[] = $newRolId;
                }
            }
            
            // Update user assignments for processed roles
            $this->updateUserAssignments($processedRoleIds, $data['rol_usuario']);
            
            $this->sql->commit('Save roles');
            
            // Return updated data
            $this->load();
            
        } catch (Exception $e) {
            $this->sql->rollback('Save roles error');
            throw $e;
        }
    }
    
    /**
     * Create new role
     */
    private function createRol(array $rol): int {
        // Validate required fields
        if (empty($rol['rol'])) {
            throw new Exception('Rol name is required', 400);
        }
        
        // Check if rol name already exists
        $exists = $this->sql->firstValue(
            "SELECT COUNT(*) FROM rol WHERE rol = ?",
            [$rol['rol']]
        );
        
        if ($exists > 0) {
            throw new Exception("Rol '{$rol['rol']}' already exists", 400);
        }
        
        $now = date('Y-m-d H:i:s');
        $currentUser = $this->getCurrentUserNick();
        
        // Prepare insert data
        $insertData = [
            'rol' => $this->sanitizeString($rol['rol']),
            'descripcion' => $this->sanitizeString($rol['descripcion'] ?? ''),
            'registrado_el' => $now,
            'registrado_por' => $currentUser
        ];
        
        // Build and execute insert
        $insert = $this->qb->insert('rol', $insertData);
        $this->sql->query($insert['query'], $insert['parameters']);
        
        return $this->sql->last_insert_id();
    }
    
    /**
     * Update existing role
     */
    private function updateRol(array $rol): void {
        $rolId = (int)$rol['rol_id'];
        
        // Check if role exists
        $exists = $this->sql->firstValue(
            "SELECT COUNT(*) FROM rol WHERE rol_id = ?",
            [$rolId]
        );
        
        if (!$exists) {
            throw new Exception("Rol ID {$rolId} not found", 404);
        }
        
        // Check if new name conflicts with existing role
        if (!empty($rol['rol'])) {
            $conflict = $this->sql->firstValue(
                "SELECT COUNT(*) FROM rol WHERE rol = ? AND rol_id != ?",
                [$rol['rol'], $rolId]
            );
            
            if ($conflict > 0) {
                throw new Exception("Rol name '{$rol['rol']}' already exists", 400);
            }
        }
        
        // Prepare update data
        $updateData = [
            'rol' => $this->sanitizeString($rol['rol']),
            'descripcion' => $this->sanitizeString($rol['descripcion'] ?? '')
        ];
        
        // Build and execute update
        $update = $this->qb->update(
            'rol',
            $updateData,
            ['rol_id' => $rolId]
        );
        
        $this->sql->query($update['query'], $update['parameters']);
    }
    
    /**
     * Update user assignments for roles
     */
    private function updateUserAssignments(array $roleIds, array $rolUsuarios): void {
        if (empty($roleIds)) {
            return;
        }
        
        $currentUser = $this->getCurrentUserNick();
        $now = date('Y-m-d H:i:s');
        
        // Delete existing assignments for these roles
        $placeholders = implode(',', array_fill(0, count($roleIds), '?'));
        $this->sql->query(
            "DELETE FROM rol_usuario WHERE rol_id IN ({$placeholders})",
            $roleIds
        );
        
        // Insert new assignments
        foreach ($rolUsuarios as $assignment) {
            $rolId = (int)($assignment['rol_id'] ?? 0);
            $usuarioId = (int)($assignment['usuario_id'] ?? 0);
            
            if ($rolId <= 0 || $usuarioId <= 0) {
                continue;
            }
            
            // Only process if rol_id is in our list
            if (!in_array($rolId, $roleIds)) {
                continue;
            }
            
            // Check if user exists
            $userExists = $this->sql->firstValue(
                "SELECT COUNT(*) FROM usuario WHERE usuario_id = ?",
                [$usuarioId]
            );
            
            if (!$userExists) {
                continue;
            }
            
            // Insert assignment
            $this->sql->query(
                "INSERT INTO rol_usuario (rol_id, usuario_id, registrado_el, registrado_por) 
                 VALUES (?, ?, ?, ?)",
                [$rolId, $usuarioId, $now, $currentUser]
            );
        }
    }
}

// Initialize and handle request
try {
    // Get database connection from config
    $sql = getSqlExecutor();
    
    // Create API instance and handle request
    $api = new RolesAPI($sql, $config);
    $api->handle();
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'data' => null
    ], JSON_UNESCAPED_UNICODE);
}
