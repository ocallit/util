<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/bootstrap.php';

$input = file_get_contents('php://input');
$request = json_decode($input, true) ?? [];
$action = $request['action'] ?? '';

try {
    match($action) {
        'list' => listPaginated($request),
        'get' => getActividad((int)($request['id'] ?? 0)),
        'create' => createRow($request['row'] ?? []),
        'update' => updateRow((int)($request['id'] ?? 0), $request['row'] ?? []),
        'delete' => deleteRow((int)($request['id'] ?? 0)),
        default => sendError("Unknown action: {$action}")
    };
} catch (Exception $e) {
    sendError($e->getMessage(), 500);
}

function listPaginated(array $request): void {
    global $gSqlExecutor;
    
    $page = (int)($request['page'] ?? 1);
    $size = (int)($request['size'] ?? 50);
    $offset = ($page - 1) * $size;
    
    $orderBy = "ORDER BY actividad_id DESC";
    if (!empty($request['sort'])) {
        $sortField = $request['sort'][0]['field'] ?? 'actividad_id';
        $sortDir = strtoupper($request['sort'][0]['dir'] ?? 'desc');
        $allowedFields = ['actividad_id', 'actividad', 'descripcion', 'registrado_el'];
        if (in_array($sortField, $allowedFields)) {
            $orderBy = "ORDER BY {$sortField} {$sortDir}";
        }
    }
    
    $where = "WHERE 1=1";
    $params = [];
    if (!empty($request['filter'])) {
        foreach ($request['filter'] as $filter) {
            $field = $filter['field'] ?? '';
            $value = $filter['value'] ?? '';
            if ($field && $value) {
                $where .= " AND {$field} LIKE ?";
                $params[] = "%{$value}%";
            }
        }
    }
    
    $total = $gSqlExecutor->firstValue("SELECT COUNT(*) FROM actividad {$where}", $params);
    
    $data = $gSqlExecutor->array(
        "SELECT a.actividad_id, a.actividad, a.descripcion, a.registrado_el, a.registrado_por,
                COUNT(ap.actividad_permiso_id) as permisos_count
         FROM actividad a
         LEFT JOIN actividad_permiso ap ON a.actividad_id = ap.actividad_id
         {$where}
         GROUP BY a.actividad_id
         {$orderBy}
         LIMIT ? OFFSET ?",
        array_merge($params, [$size, $offset])
    );
    
    jsonResponse([
        'data' => $data,
        'last_page' => $total > 0 ? ceil($total / $size) : 1,
        'last_row' => $total
    ]);
}

function getActividad(int $actividadId): void {
    global $gSqlExecutor;
    
    if (!$actividadId) {
        sendError("Actividad ID is required");
    }
    
    $actividad = $gSqlExecutor->row(
        "SELECT * FROM actividad WHERE actividad_id = ?",
        [$actividadId]
    );
    
    if (!$actividad) {
        sendError("Actividad not found");
    }
    
    $permisos = $gSqlExecutor->array(
        "SELECT * FROM actividad_permiso WHERE actividad_id = ? ORDER BY permiso",
        [$actividadId]
    );
    
    $actividad['permisos'] = $permisos;
    
    jsonResponse($actividad);
}

function createRow(array $row): void {
    global $gSqlExecutor, $gQueryBuilder;
    
    if (empty($row['actividad'])) {
        sendError("Actividad name is required");
    }
    
    $exists = $gSqlExecutor->firstValue("SELECT COUNT(*) FROM actividad WHERE actividad = ?", [$row['actividad']]);
    if ($exists) {
        sendError("Actividad '{$row['actividad']}' already exists. Choose a different name.");
    }
    
    try {
        $gSqlExecutor->begin();
        
        $now = date('Y-m-d H:i:s');
        $user = getCurrentUserNick();
        
        $insertData = [
            'actividad' => trim($row['actividad']),
            'descripcion' => trim($row['descripcion'] ?? ''),
            'registrado_el' => $now,
            'registrado_por' => $user
        ];
        
        $insert = $gQueryBuilder->insert('actividad', $insertData);
        $gSqlExecutor->query($insert['query'], $insert['parameters']);
        $actividadId = $gSqlExecutor->last_insert_id();
        
        if (!empty($row['permisos'])) {
            foreach ($row['permisos'] as $permiso) {
                $gSqlExecutor->query(
                    "INSERT INTO actividad_permiso (actividad_id, permiso, etiqueta, registrado_el, registrado_por) VALUES (?, ?, ?, ?, ?)",
                    [$actividadId, trim($permiso['permiso']), trim($permiso['etiqueta']), $now, $user]
                );
            }
        }
        
        $gSqlExecutor->commit();
        
        $newRow = $gSqlExecutor->row(
            "SELECT a.*, COUNT(ap.actividad_permiso_id) as permisos_count
             FROM actividad a
             LEFT JOIN actividad_permiso ap ON a.actividad_id = ap.actividad_id
             WHERE a.actividad_id = ?
             GROUP BY a.actividad_id",
            [$actividadId]
        );
        
        jsonResponse($newRow);
        
    } catch (Exception $e) {
        $gSqlExecutor->rollback();
        throw $e;
    }
}

function updateRow(int $actividadId, array $row): void {
    global $gSqlExecutor, $gQueryBuilder;
    
    if (!$actividadId) {
        sendError("Actividad ID is required");
    }
    
    $exists = $gSqlExecutor->firstValue("SELECT COUNT(*) FROM actividad WHERE actividad_id = ?", [$actividadId]);
    if (!$exists) {
        sendError("Actividad not found");
    }
    
    if (!empty($row['actividad'])) {
        $conflict = $gSqlExecutor->firstValue(
            "SELECT COUNT(*) FROM actividad WHERE actividad = ? AND actividad_id != ?",
            [$row['actividad'], $actividadId]
        );
        if ($conflict) {
            sendError("Actividad '{$row['actividad']}' already exists. Choose a different name.");
        }
    }
    
    try {
        $gSqlExecutor->begin();
        
        $now = date('Y-m-d H:i:s');
        $user = getCurrentUserNick();
        
        $updateData = [
            'actividad' => trim($row['actividad']),
            'descripcion' => trim($row['descripcion'] ?? '')
        ];
        
        $update = $gQueryBuilder->update('actividad', $updateData, ['actividad_id' => $actividadId]);
        $gSqlExecutor->query($update['query'], $update['parameters']);
        
        if (isset($row['permisos'])) {
            $existingIds = $gSqlExecutor->vector(
                "SELECT actividad_permiso_id FROM actividad_permiso WHERE actividad_id = ?",
                [$actividadId]
            );
            
            $processedIds = [];
            foreach ($row['permisos'] as $permiso) {
                $permisoId = (int)($permiso['actividad_permiso_id'] ?? 0);
                
                if ($permisoId > 0 && in_array($permisoId, $existingIds)) {
                    $gSqlExecutor->query(
                        "UPDATE actividad_permiso SET permiso = ?, etiqueta = ? WHERE actividad_permiso_id = ?",
                        [trim($permiso['permiso']), trim($permiso['etiqueta']), $permisoId]
                    );
                    $processedIds[] = $permisoId;
                } else {
                    $gSqlExecutor->query(
                        "INSERT INTO actividad_permiso (actividad_id, permiso, etiqueta, registrado_el, registrado_por) VALUES (?, ?, ?, ?, ?)",
                        [$actividadId, trim($permiso['permiso']), trim($permiso['etiqueta']), $now, $user]
                    );
                    $processedIds[] = $gSqlExecutor->last_insert_id();
                }
            }
            
            $toDelete = array_diff($existingIds, $processedIds);
            if (!empty($toDelete)) {
                $placeholders = implode(',', array_fill(0, count($toDelete), '?'));
                $gSqlExecutor->query(
                    "DELETE FROM actividad_permiso WHERE actividad_permiso_id IN ({$placeholders})",
                    array_values($toDelete)
                );
            }
        }
        
        $gSqlExecutor->commit();
        
        $updatedRow = $gSqlExecutor->row(
            "SELECT a.*, COUNT(ap.actividad_permiso_id) as permisos_count
             FROM actividad a
             LEFT JOIN actividad_permiso ap ON a.actividad_id = ap.actividad_id
             WHERE a.actividad_id = ?
             GROUP BY a.actividad_id",
            [$actividadId]
        );
        
        jsonResponse($updatedRow);
        
    } catch (Exception $e) {
        $gSqlExecutor->rollback();
        throw $e;
    }
}

function deleteRow(int $actividadId): void {
    global $gSqlExecutor;
    
    if (!$actividadId) {
        sendError("Actividad ID is required");
    }
    
    $exists = $gSqlExecutor->firstValue("SELECT COUNT(*) FROM actividad WHERE actividad_id = ?", [$actividadId]);
    if (!$exists) {
        sendError("Actividad not found");
    }
    
    $usageCount = $gSqlExecutor->firstValue(
        "SELECT COUNT(DISTINCT rap.rol_id)
         FROM rol_actividad_permiso rap
         JOIN actividad_permiso ap ON rap.actividad_permiso_id = ap.actividad_permiso_id
         WHERE ap.actividad_id = ?",
        [$actividadId]
    );
    if ($usageCount > 0) {
        sendError("Cannot delete actividad: {$usageCount} roles have permissions from this activity. Remove permission assignments first.");
    }
    
    try {
        $gSqlExecutor->begin();
        
        $gSqlExecutor->query("DELETE FROM actividad_permiso WHERE actividad_id = ?", [$actividadId]);
        $gSqlExecutor->query("DELETE FROM actividad WHERE actividad_id = ?", [$actividadId]);
        
        $gSqlExecutor->commit();
        
        jsonResponse(['message' => 'Actividad deleted successfully']);
        
    } catch (Exception $e) {
        $gSqlExecutor->rollback();
        throw $e;
    }
}

function sendError(string $message, int $code = 400): void {
    http_response_code($code);
    echo json_encode(['success' => false, 'error' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

function jsonResponse(mixed $data, int $code = 200): void {
    http_response_code($code);
    echo json_encode(['success' => true, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}
