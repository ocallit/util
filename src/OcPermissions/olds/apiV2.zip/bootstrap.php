<?php
declare(strict_types=1);

// ============================================================================
// BOOTSTRAP - Single source of truth for the entire application
// Include this file at the top of every page/API endpoint
// ============================================================================

// Composer autoload
require_once __DIR__ . '/../vendor/autoload.php';

use Ocallit\SqlEr\SqlExecutor;
use Ocallit\SqlEr\QueryBuilder;

// ============================================================================
// 0. GLOBAL SQL EXECUTOR (Lazy connection - SqlEr connects when first query)
// ============================================================================

$gSqlExecutor = new SqlExecutor(
    [
        'hostname' => getenv('DB_HOST') ?: 'localhost',
        'username' => getenv('DB_USER') ?: 'your_db_user',
        'password' => getenv('DB_PASS') ?: 'your_db_password',
        'database' => getenv('DB_NAME') ?: 'your_database',
        'port' => (int)(getenv('DB_PORT') ?: 3306),
    ],
    [],
    'utf8mb4',
    'utf8mb4_unicode_ci'
);

// Global QueryBuilder instance
$gQueryBuilder = new QueryBuilder();

// ============================================================================
// 1. SESSION & LOGIN CHECK
// ============================================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_lifetime' => 86400,
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax',
        'use_strict_mode' => true,
    ]);
}

function requireLogin(string $loginPage = '/login.php'): void {
    if (empty($_SESSION['user_id'])) {
        header("Location: {$loginPage}");
        exit;
    }
}

function isLoggedIn(): bool {
    return !empty($_SESSION['user_id']);
}

function getCurrentUser(): ?array {
    return $_SESSION['user'] ?? null;
}

function getCurrentUserId(): ?int {
    return $_SESSION['user_id'] ?? null;
}

function getCurrentUserNick(): string {
    return $_SESSION['user_nick'] ?? 'guest';
}

// ============================================================================
// 2. SECURITY: CSRF, DOS, HEADERS
// ============================================================================

function generateCSRFToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function validateCSRFToken(string $token): bool {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function sendSecurityHeaders(): void {
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
}

function checkRateLimit(string $action, int $maxAttempts = 10, int $windowSeconds = 60): bool {
    $key = "rate_limit_{$action}_" . ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
    
    if (!isset($_SESSION[$key])) {
        $_SESSION[$key] = ['count' => 0, 'timestamp' => time()];
    }
    
    $data = $_SESSION[$key];
    
    if (time() - $data['timestamp'] > $windowSeconds) {
        $_SESSION[$key] = ['count' => 1, 'timestamp' => time()];
        return true;
    }
    
    if ($data['count'] >= $maxAttempts) {
        return false;
    }
    
    $_SESSION[$key]['count']++;
    return true;
}

sendSecurityHeaders();

// ============================================================================
// 3. PERMISSION CHECKING (Features decide what permissions they need)
// ============================================================================

function userHasPermission(string $permission, ?int $usuarioId = null): bool {
    global $gSqlExecutor;
    
    $usuarioId = $usuarioId ?? getCurrentUserId();
    if (!$usuarioId) return false;
    
    $count = $gSqlExecutor->firstValue(
        "SELECT COUNT(*)
         FROM rol_usuario ru
         JOIN rol_actividad_permiso rap ON ru.rol_id = rap.rol_id
         JOIN actividad_permiso ap ON rap.actividad_permiso_id = ap.actividad_permiso_id
         WHERE ru.usuario_id = ? AND ap.permiso = ?",
        [$usuarioId, $permission]
    );
    
    return $count > 0;
}

function requirePermission(string $permission, string $redirectUrl = '/access-denied.php'): void {
    if (!userHasPermission($permission)) {
        header("Location: {$redirectUrl}");
        exit;
    }
}

function getUserPermissions(?int $usuarioId = null): array {
    global $gSqlExecutor;
    
    $usuarioId = $usuarioId ?? getCurrentUserId();
    if (!$usuarioId) return [];
    
    return $gSqlExecutor->vector(
        "SELECT DISTINCT ap.permiso
         FROM rol_usuario ru
         JOIN rol_actividad_permiso rap ON ru.rol_id = rap.rol_id
         JOIN actividad_permiso ap ON rap.actividad_permiso_id = ap.actividad_permiso_id
         WHERE ru.usuario_id = ?
         ORDER BY ap.permiso",
        [$usuarioId]
    );
}

// ============================================================================
// 4. CONSTANTS & CONFIGURATION
// ============================================================================

define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('TEMP_DIR', __DIR__ . '/../temp/');
define('LOG_DIR', __DIR__ . '/../logs/');
define('BASE_URL', getenv('BASE_URL') ?: 'http://localhost');
define('SITE_NAME', 'Sistema de Permisos');
define('MAX_UPLOAD_SIZE', 10 * 1024 * 1024); // 10MB

// Create directories if they don't exist
foreach ([UPLOAD_DIR, TEMP_DIR, LOG_DIR] as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
}

// ============================================================================
// 5. API KEYS (Load from secure location)
// ============================================================================

function getApiKey(string $service): ?string {
    // Load from environment variables (recommended)
    $key = getenv(strtoupper($service) . '_API_KEY');
    if ($key) return $key;
    
    // Or load from secure file outside webroot
    $keyFile = __DIR__ . '/../../.secrets/' . $service . '.key';
    if (file_exists($keyFile)) {
        return trim(file_get_contents($keyFile));
    }
    
    return null;
}

// ============================================================================
// 6. UTILITY FUNCTIONS
// ============================================================================

function sanitize(string $input): string {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function redirect(string $url, int $code = 302): void {
    header("Location: {$url}", true, $code);
    exit;
}

function jsonResponse(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function logError(string $message, array $context = []): void {
    $log = date('Y-m-d H:i:s') . ' | ' . $message;
    if (!empty($context)) {
        $log .= ' | ' . json_encode($context);
    }
    file_put_contents(LOG_DIR . 'app.log', $log . PHP_EOL, FILE_APPEND);
}

function formatDate(?string $datetime, string $format = 'Y-m-d H:i:s'): string {
    if (!$datetime) return '-';
    try {
        return (new DateTime($datetime))->format($format);
    } catch (Exception $e) {
        return $datetime;
    }
}

// ============================================================================
// 7. ERROR HANDLING
// ============================================================================

set_error_handler(function($errno, $errstr, $errfile, $errline) {
    logError("PHP Error: {$errstr}", [
        'file' => $errfile,
        'line' => $errline,
        'severity' => $errno
    ]);
    return false;
});

set_exception_handler(function($exception) {
    logError("Uncaught Exception: {$exception->getMessage()}", [
        'file' => $exception->getFile(),
        'line' => $exception->getLine(),
        'trace' => $exception->getTraceAsString()
    ]);
    
    if (getenv('APP_ENV') === 'production') {
        die('An error occurred. Please try again later.');
    } else {
        throw $exception;
    }
});

// ============================================================================
// CORS HEADERS (for API endpoints)
// ============================================================================

function enableCORS(string $origin = '*'): void {
    header("Access-Control-Allow-Origin: {$origin}");
    header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token');
    
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit;
    }
}
