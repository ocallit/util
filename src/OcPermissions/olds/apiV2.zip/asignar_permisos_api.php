<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/bootstrap.php';

$input = file_get_contents('php://input');
$request = json_decode($input, true) ?? [];
$action = $request['action'] ?? '';

try {
    match($action) {
        'list' => listPaginated($request),
        'save' => savePermissions($request),
        'roles' => getRoles(),
        'actividades' => getActividades(),
        'permisos' => getPermisos((int)($request['actividad_id'] ?? 0)),
        default => sendError("Unknown action: {$action}")
    };
} catch (Exception $e) {
    sendError($e->getMessage(), 500);
}

function listPaginated(array $request): void {
    global $gSqlExecutor;
    
    $page = (int)($request['page'] ?? 1);
    $size = (int)($request['size'] ?? 50);
    $offset = ($page - 1) * $size;
    
    $orderBy = "ORDER BY r.rol, a.actividad";
    if (!empty($request['sort'])) {
        $sortField = $request['sort'][0]['field'] ?? 'rol';
        $sortDir = strtoupper($request['sort'][0]['dir'] ?? 'asc');
        $allowedFields = ['rol', 'actividad'];
        if (in_array($sortField, $allowedFields)) {
            $orderBy = "ORDER BY {$sortField} {$sortDir}";
        }
    }
    
    $where = "WHERE 1=1";
    $params = [];
    if (!empty($request['filter'])) {
        foreach ($request['filter'] as $filter) {
            $field = $filter['field'] ?? '';
            $value = $filter['value'] ?? '';
            if ($field === 'rol' && $value) {
                $where .= " AND r.rol LIKE ?";
                $params[] = "%{$value}%";
            } elseif ($field === 'actividad' && $value) {
                $where .= " AND a.actividad LIKE ?";
                $params[] = "%{$value}%";
            }
        }
    }
    
    $totalQuery = "SELECT COUNT(*)
                   FROM rol r
                   CROSS JOIN actividad a
                   {$where}";
    $total = $gSqlExecutor->firstValue($totalQuery, $params);
    
    $data = $gSqlExecutor->array(
        "SELECT r.rol_id, r.rol, a.actividad_id, a.actividad,
                GROUP_CONCAT(DISTINCT ap.actividad_permiso_id) as permiso_ids,
                GROUP_CONCAT(DISTINCT ap.etiqueta ORDER BY ap.etiqueta SEPARATOR ', ') as permisos_text
         FROM rol r
         CROSS JOIN actividad a
         LEFT JOIN actividad_permiso ap ON a.actividad_id = ap.actividad_id
         LEFT JOIN rol_actividad_permiso rap ON r.rol_id = rap.rol_id AND ap.actividad_permiso_id = rap.actividad_permiso_id
         {$where}
         GROUP BY r.rol_id, a.actividad_id
         {$orderBy}
         LIMIT ? OFFSET ?",
        array_merge($params, [$size, $offset])
    );
    
    foreach ($data as &$row) {
        $row['permiso_ids'] = $row['permiso_ids'] ? array_map('intval', explode(',', $row['permiso_ids'])) : [];
    }
    
    jsonResponse([
        'data' => $data,
        'last_page' => $total > 0 ? ceil($total / $size) : 1,
        'last_row' => $total
    ]);
}

function savePermissions(array $request): void {
    global $gSqlExecutor;
    
    $rolId = (int)($request['rol_id'] ?? 0);
    $actividadId = (int)($request['actividad_id'] ?? 0);
    $permisoIds = $request['permisos'] ?? [];
    
    if (!$rolId || !$actividadId) {
        sendError("Rol ID and Actividad ID are required");
    }
    
    $rolExists = $gSqlExecutor->firstValue("SELECT COUNT(*) FROM rol WHERE rol_id = ?", [$rolId]);
    if (!$rolExists) {
        sendError("Rol not found");
    }
    
    $actividadExists = $gSqlExecutor->firstValue("SELECT COUNT(*) FROM actividad WHERE actividad_id = ?", [$actividadId]);
    if (!$actividadExists) {
        sendError("Actividad not found");
    }
    
    $permisoIds = array_map('intval', $permisoIds);
    
    try {
        $gSqlExecutor->begin();
        
        $activityPermisos = $gSqlExecutor->vector(
            "SELECT actividad_permiso_id FROM actividad_permiso WHERE actividad_id = ?",
            [$actividadId]
        );
        
        if (!empty($activityPermisos)) {
            $placeholders = implode(',', array_fill(0, count($activityPermisos), '?'));
            $gSqlExecutor->query(
                "DELETE FROM rol_actividad_permiso WHERE rol_id = ? AND actividad_permiso_id IN ({$placeholders})",
                array_merge([$rolId], $activityPermisos)
            );
        }
        
        if (!empty($permisoIds)) {
            $now = date('Y-m-d H:i:s');
            $user = getCurrentUserNick();
            $values = [];
            $params = [];
            
            foreach ($permisoIds as $permisoId) {
                if (in_array($permisoId, $activityPermisos)) {
                    $values[] = "(?, ?, ?, ?)";
                    $params[] = $rolId;
                    $params[] = $permisoId;
                    $params[] = $now;
                    $params[] = $user;
                }
            }
            
            if (!empty($values)) {
                $gSqlExecutor->query(
                    "INSERT INTO rol_actividad_permiso (rol_id, actividad_permiso_id, registrado_el, registrado_por) VALUES " . implode(', ', $values),
                    $params
                );
            }
        }
        
        $gSqlExecutor->commit();
        
        $updatedRow = $gSqlExecutor->row(
            "SELECT r.rol_id, r.rol, a.actividad_id, a.actividad,
                    GROUP_CONCAT(DISTINCT ap.actividad_permiso_id) as permiso_ids,
                    GROUP_CONCAT(DISTINCT ap.etiqueta ORDER BY ap.etiqueta SEPARATOR ', ') as permisos_text
             FROM rol r
             CROSS JOIN actividad a
             LEFT JOIN actividad_permiso ap ON a.actividad_id = ap.actividad_id
             LEFT JOIN rol_actividad_permiso rap ON r.rol_id = rap.rol_id AND ap.actividad_permiso_id = rap.actividad_permiso_id
             WHERE r.rol_id = ? AND a.actividad_id = ?
             GROUP BY r.rol_id, a.actividad_id",
            [$rolId, $actividadId]
        );
        
        if ($updatedRow) {
            $updatedRow['permiso_ids'] = $updatedRow['permiso_ids'] ? array_map('intval', explode(',', $updatedRow['permiso_ids'])) : [];
        }
        
        jsonResponse($updatedRow ?: ['message' => 'Permissions saved successfully']);
        
    } catch (Exception $e) {
        $gSqlExecutor->rollback();
        throw $e;
    }
}

function getRoles(): void {
    global $gSqlExecutor;
    
    $roles = $gSqlExecutor->array("SELECT rol_id, rol, descripcion FROM rol ORDER BY rol");
    
    jsonResponse($roles);
}

function getActividades(): void {
    global $gSqlExecutor;
    
    $actividades = $gSqlExecutor->array("SELECT actividad_id, actividad, descripcion FROM actividad ORDER BY actividad");
    
    jsonResponse($actividades);
}

function getPermisos(int $actividadId): void {
    global $gSqlExecutor;
    
    if (!$actividadId) {
        sendError("Actividad ID is required");
    }
    
    $permisos = $gSqlExecutor->array(
        "SELECT actividad_permiso_id, permiso, etiqueta FROM actividad_permiso WHERE actividad_id = ? ORDER BY permiso",
        [$actividadId]
    );
    
    jsonResponse($permisos);
}

function sendError(string $message, int $code = 400): void {
    http_response_code($code);
    echo json_encode(['success' => false, 'error' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

function jsonResponse(mixed $data, int $code = 200): void {
    http_response_code($code);
    echo json_encode(['success' => true, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}
