<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/bootstrap.php';

$input = file_get_contents('php://input');
$request = json_decode($input, true) ?? [];
$action = $request['action'] ?? '';

try {
    match($action) {
        'list' => listPaginated($request),
        'create' => createRow($request['row'] ?? []),
        'update' => updateRow((int)($request['id'] ?? 0), $request['row'] ?? []),
        'delete' => deleteRow((int)($request['id'] ?? 0)),
        'roles' => getRoles(),
        default => sendError("Unknown action: {$action}")
    };
} catch (Exception $e) {
    sendError($e->getMessage(), 500);
}

function listPaginated(array $request): void {
    global $gSqlExecutor;
    
    $page = (int)($request['page'] ?? 1);
    $size = (int)($request['size'] ?? 50);
    $offset = ($page - 1) * $size;
    
    $orderBy = "ORDER BY usuario_id DESC";
    if (!empty($request['sort'])) {
        $sortField = $request['sort'][0]['field'] ?? 'usuario_id';
        $sortDir = strtoupper($request['sort'][0]['dir'] ?? 'desc');
        $allowedFields = ['usuario_id', 'nick', 'nombre', 'email', 'estatus', 'creado_el'];
        if (in_array($sortField, $allowedFields)) {
            $orderBy = "ORDER BY {$sortField} {$sortDir}";
        }
    }
    
    $where = "WHERE 1=1";
    $params = [];
    if (!empty($request['filter'])) {
        foreach ($request['filter'] as $filter) {
            $field = $filter['field'] ?? '';
            $value = $filter['value'] ?? '';
            if ($field && $value) {
                $where .= " AND {$field} LIKE ?";
                $params[] = "%{$value}%";
            }
        }
    }
    
    $total = $gSqlExecutor->firstValue("SELECT COUNT(*) FROM usuario {$where}", $params);
    
    $data = $gSqlExecutor->array(
        "SELECT u.usuario_id, u.nick, u.nombre, u.email, u.cel, u.estatus, u.nota,
                u.password_forza_cambio, u.password_caducidad_dias, u.password_ultimo_cambio,
                u.ultimo_login, u.creado_el, u.creado_por, u.ultimo_cambio_el, u.ultimo_cambio_por,
                GROUP_CONCAT(DISTINCT r.rol_id) as rol_ids,
                GROUP_CONCAT(DISTINCT r.rol SEPARATOR ', ') as roles_text
         FROM usuario u
         LEFT JOIN rol_usuario ru ON u.usuario_id = ru.usuario_id
         LEFT JOIN rol r ON ru.rol_id = r.rol_id
         {$where}
         GROUP BY u.usuario_id
         {$orderBy}
         LIMIT ? OFFSET ?",
        array_merge($params, [$size, $offset])
    );
    
    foreach ($data as &$row) {
        $row['rol_ids'] = $row['rol_ids'] ? explode(',', $row['rol_ids']) : [];
    }
    
    jsonResponse([
        'data' => $data,
        'last_page' => $total > 0 ? ceil($total / $size) : 1,
        'last_row' => $total
    ]);
}

function createRow(array $row): void {
    global $gSqlExecutor, $gQueryBuilder;
    
    if (empty($row['nick'])) {
        sendError("Nick is required");
    }
    if (empty($row['nombre'])) {
        sendError("Nombre is required");
    }
    if (empty($row['password'])) {
        sendError("Password is required for new users");
    }
    
    $exists = $gSqlExecutor->firstValue("SELECT COUNT(*) FROM usuario WHERE nick = ?", [$row['nick']]);
    if ($exists) {
        sendError("Nick '{$row['nick']}' already exists. Choose a different username.");
    }
    
    try {
        $gSqlExecutor->begin();
        
        $now = date('Y-m-d H:i:s');
        $user = getCurrentUserNick();
        
        $insertData = [
            'nick' => trim($row['nick']),
            'nombre' => trim($row['nombre']),
            'email' => trim($row['email'] ?? ''),
            'cel' => trim($row['cel'] ?? ''),
            'estatus' => $row['estatus'] ?? 'Puede Login',
            'nota' => trim($row['nota'] ?? ''),
            'password' => password_hash($row['password'], PASSWORD_DEFAULT),
            'password_forza_cambio' => $row['password_forza_cambio'] ?? 'Si',
            'password_caducidad_dias' => (int)($row['password_caducidad_dias'] ?? 90),
            'password_ultimo_cambio' => $now,
            'creado_el' => $now,
            'creado_por' => $user,
            'ultimo_cambio_el' => $now,
            'ultimo_cambio_por' => $user
        ];
        
        $insert = $gQueryBuilder->insert('usuario', $insertData);
        $gSqlExecutor->query($insert['query'], $insert['parameters']);
        $usuarioId = $gSqlExecutor->last_insert_id();
        
        if (!empty($row['rol_ids'])) {
            foreach ($row['rol_ids'] as $rolId) {
                $gSqlExecutor->query(
                    "INSERT INTO rol_usuario (rol_id, usuario_id, registrado_el, registrado_por) VALUES (?, ?, ?, ?)",
                    [(int)$rolId, $usuarioId, $now, $user]
                );
            }
        }
        
        $gSqlExecutor->commit();
        
        $newRow = $gSqlExecutor->row(
            "SELECT u.*, GROUP_CONCAT(DISTINCT r.rol SEPARATOR ', ') as roles_text
             FROM usuario u
             LEFT JOIN rol_usuario ru ON u.usuario_id = ru.usuario_id
             LEFT JOIN rol r ON ru.rol_id = r.rol_id
             WHERE u.usuario_id = ?
             GROUP BY u.usuario_id",
            [$usuarioId]
        );
        
        $newRow['rol_ids'] = !empty($row['rol_ids']) ? $row['rol_ids'] : [];
        
        jsonResponse($newRow);
        
    } catch (Exception $e) {
        $gSqlExecutor->rollback();
        throw $e;
    }
}

function updateRow(int $usuarioId, array $row): void {
    global $gSqlExecutor, $gQueryBuilder;
    
    if (!$usuarioId) {
        sendError("Usuario ID is required");
    }
    
    $exists = $gSqlExecutor->firstValue("SELECT COUNT(*) FROM usuario WHERE usuario_id = ?", [$usuarioId]);
    if (!$exists) {
        sendError("User not found");
    }
    
    if (!empty($row['nick'])) {
        $conflict = $gSqlExecutor->firstValue(
            "SELECT COUNT(*) FROM usuario WHERE nick = ? AND usuario_id != ?",
            [$row['nick'], $usuarioId]
        );
        if ($conflict) {
            sendError("Nick '{$row['nick']}' already exists. Choose a different username.");
        }
    }
    
    try {
        $gSqlExecutor->begin();
        
        $now = date('Y-m-d H:i:s');
        $user = getCurrentUserNick();
        
        $updateData = [
            'nick' => trim($row['nick']),
            'nombre' => trim($row['nombre']),
            'email' => trim($row['email'] ?? ''),
            'cel' => trim($row['cel'] ?? ''),
            'estatus' => $row['estatus'] ?? 'Puede Login',
            'nota' => trim($row['nota'] ?? ''),
            'password_forza_cambio' => $row['password_forza_cambio'] ?? 'No',
            'password_caducidad_dias' => (int)($row['password_caducidad_dias'] ?? 90),
            'ultimo_cambio_el' => $now,
            'ultimo_cambio_por' => $user
        ];
        
        if (!empty($row['password'])) {
            $updateData['password'] = password_hash($row['password'], PASSWORD_DEFAULT);
            $updateData['password_ultimo_cambio'] = $now;
        }
        
        $update = $gQueryBuilder->update('usuario', $updateData, ['usuario_id' => $usuarioId]);
        $gSqlExecutor->query($update['query'], $update['parameters']);
        
        $gSqlExecutor->query("DELETE FROM rol_usuario WHERE usuario_id = ?", [$usuarioId]);
        
        if (!empty($row['rol_ids'])) {
            foreach ($row['rol_ids'] as $rolId) {
                $gSqlExecutor->query(
                    "INSERT INTO rol_usuario (rol_id, usuario_id, registrado_el, registrado_por) VALUES (?, ?, ?, ?)",
                    [(int)$rolId, $usuarioId, $now, $user]
                );
            }
        }
        
        $gSqlExecutor->commit();
        
        $updatedRow = $gSqlExecutor->row(
            "SELECT u.*, GROUP_CONCAT(DISTINCT r.rol SEPARATOR ', ') as roles_text
             FROM usuario u
             LEFT JOIN rol_usuario ru ON u.usuario_id = ru.usuario_id
             LEFT JOIN rol r ON ru.rol_id = r.rol_id
             WHERE u.usuario_id = ?
             GROUP BY u.usuario_id",
            [$usuarioId]
        );
        
        $updatedRow['rol_ids'] = !empty($row['rol_ids']) ? $row['rol_ids'] : [];
        
        jsonResponse($updatedRow);
        
    } catch (Exception $e) {
        $gSqlExecutor->rollback();
        throw $e;
    }
}

function deleteRow(int $usuarioId): void {
    global $gSqlExecutor;
    
    if (!$usuarioId) {
        sendError("Usuario ID is required");
    }
    
    $exists = $gSqlExecutor->firstValue("SELECT COUNT(*) FROM usuario WHERE usuario_id = ?", [$usuarioId]);
    if (!$exists) {
        sendError("User not found");
    }
    
    try {
        $gSqlExecutor->begin();
        
        $gSqlExecutor->query("DELETE FROM rol_usuario WHERE usuario_id = ?", [$usuarioId]);
        $gSqlExecutor->query("DELETE FROM usuario WHERE usuario_id = ?", [$usuarioId]);
        
        $gSqlExecutor->commit();
        
        jsonResponse(['message' => 'User deleted successfully']);
        
    } catch (Exception $e) {
        $gSqlExecutor->rollback();
        throw $e;
    }
}

function getRoles(): void {
    global $gSqlExecutor;
    
    $roles = $gSqlExecutor->array("SELECT rol_id, rol FROM rol ORDER BY rol");
    
    jsonResponse($roles);
}

function sendError(string $message, int $code = 400): void {
    http_response_code($code);
    echo json_encode(['success' => false, 'error' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

function jsonResponse(mixed $data, int $code = 200): void {
    http_response_code($code);
    echo json_encode(['success' => true, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}
