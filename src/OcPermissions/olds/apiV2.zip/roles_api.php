<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/bootstrap.php';

$input = file_get_contents('php://input');
$request = json_decode($input, true) ?? [];
$action = $request['action'] ?? '';

try {
    match($action) {
        'list' => listPaginated($request),
        'create' => createRow($request['row'] ?? []),
        'update' => updateRow((int)($request['id'] ?? 0), $request['row'] ?? []),
        'delete' => deleteRow((int)($request['id'] ?? 0)),
        'usuarios' => getUsuarios(),
        default => sendError("Unknown action: {$action}")
    };
} catch (Exception $e) {
    sendError($e->getMessage(), 500);
}

function listPaginated(array $request): void {
    global $gSqlExecutor;
    
    $page = (int)($request['page'] ?? 1);
    $size = (int)($request['size'] ?? 50);
    $offset = ($page - 1) * $size;
    
    $orderBy = "ORDER BY rol_id DESC";
    if (!empty($request['sort'])) {
        $sortField = $request['sort'][0]['field'] ?? 'rol_id';
        $sortDir = strtoupper($request['sort'][0]['dir'] ?? 'desc');
        $allowedFields = ['rol_id', 'rol', 'descripcion', 'registrado_el'];
        if (in_array($sortField, $allowedFields)) {
            $orderBy = "ORDER BY {$sortField} {$sortDir}";
        }
    }
    
    $where = "WHERE 1=1";
    $params = [];
    if (!empty($request['filter'])) {
        foreach ($request['filter'] as $filter) {
            $field = $filter['field'] ?? '';
            $value = $filter['value'] ?? '';
            if ($field && $value) {
                $where .= " AND {$field} LIKE ?";
                $params[] = "%{$value}%";
            }
        }
    }
    
    $total = $gSqlExecutor->firstValue("SELECT COUNT(*) FROM rol {$where}", $params);
    
    $data = $gSqlExecutor->array(
        "SELECT r.rol_id, r.rol, r.descripcion, r.registrado_el, r.registrado_por,
                GROUP_CONCAT(DISTINCT u.usuario_id) as usuario_ids,
                GROUP_CONCAT(DISTINCT u.nick SEPARATOR ', ') as usuarios_text
         FROM rol r
         LEFT JOIN rol_usuario ru ON r.rol_id = ru.rol_id
         LEFT JOIN usuario u ON ru.usuario_id = u.usuario_id
         {$where}
         GROUP BY r.rol_id
         {$orderBy}
         LIMIT ? OFFSET ?",
        array_merge($params, [$size, $offset])
    );
    
    foreach ($data as &$row) {
        $row['usuario_ids'] = $row['usuario_ids'] ? explode(',', $row['usuario_ids']) : [];
    }
    
    jsonResponse([
        'data' => $data,
        'last_page' => $total > 0 ? ceil($total / $size) : 1,
        'last_row' => $total
    ]);
}

function createRow(array $row): void {
    global $gSqlExecutor, $gQueryBuilder;
    
    if (empty($row['rol'])) {
        sendError("Rol name is required");
    }
    
    $exists = $gSqlExecutor->firstValue("SELECT COUNT(*) FROM rol WHERE rol = ?", [$row['rol']]);
    if ($exists) {
        sendError("Rol '{$row['rol']}' already exists. Choose a different name.");
    }
    
    try {
        $gSqlExecutor->begin();
        
        $now = date('Y-m-d H:i:s');
        $user = getCurrentUserNick();
        
        $insertData = [
            'rol' => trim($row['rol']),
            'descripcion' => trim($row['descripcion'] ?? ''),
            'registrado_el' => $now,
            'registrado_por' => $user
        ];
        
        $insert = $gQueryBuilder->insert('rol', $insertData);
        $gSqlExecutor->query($insert['query'], $insert['parameters']);
        $rolId = $gSqlExecutor->last_insert_id();
        
        if (!empty($row['usuario_ids'])) {
            foreach ($row['usuario_ids'] as $usuarioId) {
                $gSqlExecutor->query(
                    "INSERT INTO rol_usuario (rol_id, usuario_id, registrado_el, registrado_por) VALUES (?, ?, ?, ?)",
                    [$rolId, (int)$usuarioId, $now, $user]
                );
            }
        }
        
        $gSqlExecutor->commit();
        
        $newRow = $gSqlExecutor->row(
            "SELECT r.*, GROUP_CONCAT(DISTINCT u.nick SEPARATOR ', ') as usuarios_text
             FROM rol r
             LEFT JOIN rol_usuario ru ON r.rol_id = ru.rol_id
             LEFT JOIN usuario u ON ru.usuario_id = u.usuario_id
             WHERE r.rol_id = ?
             GROUP BY r.rol_id",
            [$rolId]
        );
        
        $newRow['usuario_ids'] = !empty($row['usuario_ids']) ? $row['usuario_ids'] : [];
        
        jsonResponse($newRow);
        
    } catch (Exception $e) {
        $gSqlExecutor->rollback();
        throw $e;
    }
}

function updateRow(int $rolId, array $row): void {
    global $gSqlExecutor, $gQueryBuilder;
    
    if (!$rolId) {
        sendError("Rol ID is required");
    }
    
    $exists = $gSqlExecutor->firstValue("SELECT COUNT(*) FROM rol WHERE rol_id = ?", [$rolId]);
    if (!$exists) {
        sendError("Rol not found");
    }
    
    if (!empty($row['rol'])) {
        $conflict = $gSqlExecutor->firstValue(
            "SELECT COUNT(*) FROM rol WHERE rol = ? AND rol_id != ?",
            [$row['rol'], $rolId]
        );
        if ($conflict) {
            sendError("Rol '{$row['rol']}' already exists. Choose a different name.");
        }
    }
    
    try {
        $gSqlExecutor->begin();
        
        $now = date('Y-m-d H:i:s');
        $user = getCurrentUserNick();
        
        $updateData = [
            'rol' => trim($row['rol']),
            'descripcion' => trim($row['descripcion'] ?? '')
        ];
        
        $update = $gQueryBuilder->update('rol', $updateData, ['rol_id' => $rolId]);
        $gSqlExecutor->query($update['query'], $update['parameters']);
        
        $gSqlExecutor->query("DELETE FROM rol_usuario WHERE rol_id = ?", [$rolId]);
        
        if (!empty($row['usuario_ids'])) {
            foreach ($row['usuario_ids'] as $usuarioId) {
                $gSqlExecutor->query(
                    "INSERT INTO rol_usuario (rol_id, usuario_id, registrado_el, registrado_por) VALUES (?, ?, ?, ?)",
                    [$rolId, (int)$usuarioId, $now, $user]
                );
            }
        }
        
        $gSqlExecutor->commit();
        
        $updatedRow = $gSqlExecutor->row(
            "SELECT r.*, GROUP_CONCAT(DISTINCT u.nick SEPARATOR ', ') as usuarios_text
             FROM rol r
             LEFT JOIN rol_usuario ru ON r.rol_id = ru.rol_id
             LEFT JOIN usuario u ON ru.usuario_id = u.usuario_id
             WHERE r.rol_id = ?
             GROUP BY r.rol_id",
            [$rolId]
        );
        
        $updatedRow['usuario_ids'] = !empty($row['usuario_ids']) ? $row['usuario_ids'] : [];
        
        jsonResponse($updatedRow);
        
    } catch (Exception $e) {
        $gSqlExecutor->rollback();
        throw $e;
    }
}

function deleteRow(int $rolId): void {
    global $gSqlExecutor;
    
    if (!$rolId) {
        sendError("Rol ID is required");
    }
    
    $exists = $gSqlExecutor->firstValue("SELECT COUNT(*) FROM rol WHERE rol_id = ?", [$rolId]);
    if (!$exists) {
        sendError("Rol not found");
    }
    
    $usageCount = $gSqlExecutor->firstValue(
        "SELECT COUNT(*) FROM rol_actividad_permiso WHERE rol_id = ?",
        [$rolId]
    );
    if ($usageCount > 0) {
        sendError("Cannot delete rol: it has {$usageCount} permission assignments. Remove permissions first.");
    }
    
    try {
        $gSqlExecutor->begin();
        
        $gSqlExecutor->query("DELETE FROM rol_usuario WHERE rol_id = ?", [$rolId]);
        $gSqlExecutor->query("DELETE FROM rol WHERE rol_id = ?", [$rolId]);
        
        $gSqlExecutor->commit();
        
        jsonResponse(['message' => 'Rol deleted successfully']);
        
    } catch (Exception $e) {
        $gSqlExecutor->rollback();
        throw $e;
    }
}

function getUsuarios(): void {
    global $gSqlExecutor;
    
    $usuarios = $gSqlExecutor->array("SELECT usuario_id, nick, nombre FROM usuario ORDER BY nombre");
    
    jsonResponse($usuarios);
}

function sendError(string $message, int $code = 400): void {
    http_response_code($code);
    echo json_encode(['success' => false, 'error' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

function jsonResponse(mixed $data, int $code = 200): void {
    http_response_code($code);
    echo json_encode(['success' => true, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}
