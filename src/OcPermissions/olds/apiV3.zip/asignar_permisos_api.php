<?php
/**
 * asignar_permisos_api.php
 * API for managing permission assignments to roles (rol_actividad_permiso)
 */

declare(strict_types=1);

require_once __DIR__ . '/../config.php';

use Ocallit\SqlEr\SqlEr;

header('Content-Type: application/json; charset=utf-8');

try {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $action = $input['action'] ?? '';

    $db = SqlEr::getInstance();

    switch ($action) {
        case 'load':
            echo json_encode(loadState($db));
            break;

        case 'save':
            echo json_encode(saveState($db, $input['data'] ?? []));
            break;

        case 'assign':
            echo json_encode(assignPermissions($db, $input));
            break;

        case 'unassign':
            echo json_encode(unassignPermission($db, $input));
            break;

        case 'get_matrix':
            echo json_encode(getPermissionMatrix($db));
            break;

        default:
            echo json_encode([
                'success' => false,
                'error' => 'Acción desconocida: ' . $action,
                'data' => null
            ]);
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'data' => null
    ]);
}

/**
 * Load complete state: roles, actividades, actividad_permisos, asignaciones
 */
function loadState(SqlEr $db): array
{
    $roles = $db->query("
        SELECT rol_id, rol, descripcion
        FROM rol
        ORDER BY rol
    ") ?: [];

    $actividades = $db->query("
        SELECT actividad_id, actividad, descripcion
        FROM actividad
        ORDER BY actividad
    ") ?: [];

    $actividad_permisos = $db->query("
        SELECT actividad_permiso_id, actividad_id, permiso, etiqueta
        FROM actividad_permiso
        ORDER BY actividad_id, actividad_permiso_id
    ") ?: [];

    // Build asignaciones map: rol_id => [actividad_permiso_id, ...]
    $asignacionesRaw = $db->query("
        SELECT rol_id, actividad_permiso_id
        FROM rol_actividad_permiso
    ") ?: [];

    $asignaciones = [];
    foreach ($asignacionesRaw as $a) {
        $rolId = (int)$a['rol_id'];
        if (!isset($asignaciones[$rolId])) {
            $asignaciones[$rolId] = [];
        }
        $asignaciones[$rolId][] = (int)$a['actividad_permiso_id'];
    }

    // Build rowPairs from existing assignments (unique rol_id + actividad_id combinations)
    $rowPairs = [];
    $seen = [];

    // Get all actividad_id for each actividad_permiso_id
    $permToActividad = [];
    foreach ($actividad_permisos as $ap) {
        $permToActividad[(int)$ap['actividad_permiso_id']] = (int)$ap['actividad_id'];
    }

    foreach ($asignacionesRaw as $a) {
        $rolId = (int)$a['rol_id'];
        $permId = (int)$a['actividad_permiso_id'];
        $actId = $permToActividad[$permId] ?? 0;

        if ($actId > 0) {
            $key = $rolId . '-' . $actId;
            if (!isset($seen[$key])) {
                $rowPairs[] = ['rol_id' => $rolId, 'actividad_id' => $actId];
                $seen[$key] = true;
            }
        }
    }

    return [
        'success' => true,
        'error' => null,
        'data' => [
            'roles' => $roles,
            'actividades' => $actividades,
            'actividad_permisos' => $actividad_permisos,
            'asignaciones' => $asignaciones,
            'rowPairs' => $rowPairs
        ]
    ];
}

/**
 * Save complete state (bulk update - used by JS frontend)
 */
function saveState(SqlEr $db, array $data): array
{
    $asignaciones = $data['asignaciones'] ?? [];
    $currentUser = $_SESSION['nick'] ?? 'system';

    $db->beginTransaction();

    try {
        // Clear all assignments
        $db->execute("DELETE FROM rol_actividad_permiso");

        // Insert new assignments
        foreach ($asignaciones as $rolId => $permIds) {
            $rolId = (int)$rolId;
            
            // Handle both array and Set-like structures
            if (is_array($permIds)) {
                foreach ($permIds as $permId) {
                    $permId = (int)$permId;
                    if ($permId > 0) {
                        $db->insert('rol_actividad_permiso', [
                            'rol_id' => $rolId,
                            'actividad_permiso_id' => $permId,
                            'registrado_por' => $currentUser
                        ]);
                    }
                }
            }
        }

        $db->commit();

        return loadState($db);

    } catch (Throwable $e) {
        $db->rollBack();
        return ['success' => false, 'error' => $e->getMessage(), 'data' => null];
    }
}

/**
 * Assign specific permissions to a role for an activity
 */
function assignPermissions(SqlEr $db, array $input): array
{
    $rol_id = (int)($input['rol_id'] ?? 0);
    $actividad_id = (int)($input['actividad_id'] ?? 0);
    $permiso_ids = $input['permiso_ids'] ?? [];

    if ($rol_id <= 0 || $actividad_id <= 0) {
        return ['success' => false, 'error' => 'rol_id y actividad_id son requeridos', 'data' => null];
    }

    $currentUser = $_SESSION['nick'] ?? 'system';

    $db->beginTransaction();

    try {
        // Get all permission IDs for this activity
        $activityPerms = $db->query("
            SELECT actividad_permiso_id 
            FROM actividad_permiso 
            WHERE actividad_id = ?
        ", [$actividad_id]) ?: [];
        
        $activityPermIds = array_column($activityPerms, 'actividad_permiso_id');

        // Remove existing assignments for this rol + actividad combination
        if (!empty($activityPermIds)) {
            $placeholders = implode(',', array_fill(0, count($activityPermIds), '?'));
            $params = array_merge([$rol_id], $activityPermIds);
            $db->execute("
                DELETE FROM rol_actividad_permiso 
                WHERE rol_id = ? AND actividad_permiso_id IN ($placeholders)
            ", $params);
        }

        // Insert new assignments
        foreach ($permiso_ids as $permId) {
            $permId = (int)$permId;
            if ($permId > 0 && in_array($permId, $activityPermIds, true)) {
                $db->insert('rol_actividad_permiso', [
                    'rol_id' => $rol_id,
                    'actividad_permiso_id' => $permId,
                    'registrado_por' => $currentUser
                ]);
            }
        }

        $db->commit();

        return ['success' => true, 'error' => null, 'data' => null];

    } catch (Throwable $e) {
        $db->rollBack();
        return ['success' => false, 'error' => $e->getMessage(), 'data' => null];
    }
}

/**
 * Unassign a specific permission from a role
 */
function unassignPermission(SqlEr $db, array $input): array
{
    $rol_id = (int)($input['rol_id'] ?? 0);
    $actividad_permiso_id = (int)($input['actividad_permiso_id'] ?? 0);

    if ($rol_id <= 0 || $actividad_permiso_id <= 0) {
        return ['success' => false, 'error' => 'rol_id y actividad_permiso_id son requeridos', 'data' => null];
    }

    $db->execute("
        DELETE FROM rol_actividad_permiso 
        WHERE rol_id = ? AND actividad_permiso_id = ?
    ", [$rol_id, $actividad_permiso_id]);

    return ['success' => true, 'error' => null, 'data' => null];
}

/**
 * Get complete permission matrix for display
 */
function getPermissionMatrix(SqlEr $db): array
{
    $roles = $db->query("
        SELECT rol_id, rol, descripcion
        FROM rol
        ORDER BY rol
    ") ?: [];

    $actividades = $db->query("
        SELECT actividad_id, actividad, descripcion
        FROM actividad
        ORDER BY actividad
    ") ?: [];

    $matrix = [];

    foreach ($roles as $role) {
        $rolId = (int)$role['rol_id'];
        $matrix[$rolId] = [
            'rol' => $role,
            'actividades' => []
        ];

        foreach ($actividades as $act) {
            $actId = (int)$act['actividad_id'];

            // Get all permissions for this activity
            $permisos = $db->query("
                SELECT ap.actividad_permiso_id, ap.permiso, ap.etiqueta,
                       CASE WHEN rap.rol_id IS NOT NULL THEN 1 ELSE 0 END as asignado
                FROM actividad_permiso ap
                LEFT JOIN rol_actividad_permiso rap 
                    ON ap.actividad_permiso_id = rap.actividad_permiso_id 
                    AND rap.rol_id = ?
                WHERE ap.actividad_id = ?
                ORDER BY ap.actividad_permiso_id
            ", [$rolId, $actId]) ?: [];

            $matrix[$rolId]['actividades'][$actId] = [
                'actividad' => $act,
                'permisos' => $permisos
            ];
        }
    }

    return ['success' => true, 'error' => null, 'data' => $matrix];
}
