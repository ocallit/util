<?php
/**
 * usuarios_api.php
 * API for managing users (usuario) and their role assignments (rol_usuario)
 */

declare(strict_types=1);

require_once __DIR__ . '/../config.php';

use Ocallit\SqlEr\SqlEr;

header('Content-Type: application/json; charset=utf-8');

try {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $action = $input['action'] ?? '';

    $db = SqlEr::getInstance();

    switch ($action) {
        case 'load':
            echo json_encode(loadState($db));
            break;

        case 'save':
            echo json_encode(saveState($db, $input['data'] ?? []));
            break;

        case 'list':
            echo json_encode(listUsuarios($db));
            break;

        case 'get':
            $id = (int)($input['usuario_id'] ?? 0);
            echo json_encode(getUsuario($db, $id));
            break;

        case 'save_usuario':
            echo json_encode(saveUsuario($db, $input));
            break;

        case 'delete':
            $id = (int)($input['usuario_id'] ?? 0);
            echo json_encode(deleteUsuario($db, $id));
            break;

        default:
            echo json_encode([
                'success' => false,
                'error' => 'Acción desconocida: ' . $action,
                'data' => null
            ]);
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'data' => null
    ]);
}

/**
 * Load complete state: usuarios, roles, rol_usuario
 */
function loadState(SqlEr $db): array
{
    $usuarios = $db->query("
        SELECT usuario_id, nick, estatus, nota, nombre, email, cel,
               password_forza_cambio, password_caducidad_dias, password_ultimo_cambio,
               ultimo_login, creado_el, creado_por, ultimo_cambio_el, ultimo_cambio_por
        FROM usuario
        ORDER BY nick
    ") ?: [];

    $roles = $db->query("
        SELECT rol_id, rol
        FROM rol
        ORDER BY rol
    ") ?: [];

    $rol_usuario = $db->query("
        SELECT rol_id, usuario_id
        FROM rol_usuario
    ") ?: [];

    return [
        'success' => true,
        'error' => null,
        'data' => [
            'usuarios' => $usuarios,
            'roles' => $roles,
            'rol_usuario' => $rol_usuario
        ]
    ];
}

/**
 * List all users with their roles
 */
function listUsuarios(SqlEr $db): array
{
    $usuarios = $db->query("
        SELECT u.usuario_id, u.nick, u.estatus, u.nota, u.nombre, u.email, u.cel,
               u.password_forza_cambio, u.password_caducidad_dias, u.password_ultimo_cambio,
               u.ultimo_login, u.creado_el, u.creado_por, u.ultimo_cambio_el, u.ultimo_cambio_por,
               GROUP_CONCAT(r.rol ORDER BY r.rol SEPARATOR ', ') as roles_text
        FROM usuario u
        LEFT JOIN rol_usuario ru ON u.usuario_id = ru.usuario_id
        LEFT JOIN rol r ON ru.rol_id = r.rol_id
        GROUP BY u.usuario_id
        ORDER BY u.nick
    ") ?: [];

    return ['success' => true, 'error' => null, 'data' => $usuarios];
}

/**
 * Get single user with roles
 */
function getUsuario(SqlEr $db, int $id): array
{
    if ($id <= 0) {
        return ['success' => false, 'error' => 'ID de usuario inválido', 'data' => null];
    }

    $usuario = $db->queryRow("
        SELECT usuario_id, nick, estatus, nota, nombre, email, cel,
               password_forza_cambio, password_caducidad_dias, password_ultimo_cambio,
               ultimo_login, creado_el, creado_por, ultimo_cambio_el, ultimo_cambio_por
        FROM usuario
        WHERE usuario_id = ?
    ", [$id]);

    if (!$usuario) {
        return ['success' => false, 'error' => 'Usuario no encontrado', 'data' => null];
    }

    $usuario['roles'] = $db->query("
        SELECT r.rol_id, r.rol
        FROM rol r
        INNER JOIN rol_usuario ru ON r.rol_id = ru.rol_id
        WHERE ru.usuario_id = ?
        ORDER BY r.rol
    ", [$id]) ?: [];

    return ['success' => true, 'error' => null, 'data' => $usuario];
}

/**
 * Save single user with roles
 */
function saveUsuario(SqlEr $db, array $input): array
{
    $usuario_id = isset($input['usuario_id']) ? (int)$input['usuario_id'] : 0;
    $nick = trim($input['nick'] ?? '');
    $nombre = trim($input['nombre'] ?? '');
    $email = trim($input['email'] ?? '');
    $cel = trim($input['cel'] ?? '');
    $estatus = $input['estatus'] ?? 'Puede Login';
    $nota = trim($input['nota'] ?? '');
    $password = $input['password'] ?? '';
    $password_forza_cambio = $input['password_forza_cambio'] ?? 'No';
    $password_caducidad_dias = (int)($input['password_caducidad_dias'] ?? 90);
    $roles = $input['roles'] ?? [];

    if ($nick === '' || $nombre === '') {
        return ['success' => false, 'error' => 'Nick y Nombre son requeridos', 'data' => null];
    }

    $currentUser = $_SESSION['nick'] ?? 'system';
    $now = date('Y-m-d H:i:s');

    $db->beginTransaction();

    try {
        if ($usuario_id > 0) {
            // Update existing user
            $updateData = [
                'nick' => $nick,
                'nombre' => $nombre,
                'email' => $email,
                'cel' => $cel,
                'estatus' => $estatus,
                'nota' => $nota,
                'password_forza_cambio' => $password_forza_cambio,
                'password_caducidad_dias' => $password_caducidad_dias,
                'ultimo_cambio_el' => $now,
                'ultimo_cambio_por' => $currentUser
            ];

            // Update password if provided
            if ($password !== '') {
                $updateData['password'] = password_hash($password, PASSWORD_DEFAULT);
                $updateData['password_ultimo_cambio'] = $now;
            }

            $db->update('usuario', $updateData, 'usuario_id = ?', [$usuario_id]);
        } else {
            // Insert new user - password required
            if ($password === '') {
                $db->rollBack();
                return ['success' => false, 'error' => 'Password requerido para nuevos usuarios', 'data' => null];
            }

            $db->insert('usuario', [
                'nick' => $nick,
                'nombre' => $nombre,
                'email' => $email,
                'cel' => $cel,
                'estatus' => $estatus,
                'nota' => $nota,
                'password' => password_hash($password, PASSWORD_DEFAULT),
                'password_forza_cambio' => $password_forza_cambio,
                'password_caducidad_dias' => $password_caducidad_dias,
                'password_ultimo_cambio' => $now,
                'creado_el' => $now,
                'creado_por' => $currentUser,
                'ultimo_cambio_el' => $now,
                'ultimo_cambio_por' => $currentUser
            ]);
            $usuario_id = (int)$db->lastInsertId();
        }

        // Update role assignments
        $db->execute("DELETE FROM rol_usuario WHERE usuario_id = ?", [$usuario_id]);

        foreach ($roles as $rol_id) {
            $rol_id = (int)$rol_id;
            if ($rol_id > 0) {
                $db->insert('rol_usuario', [
                    'rol_id' => $rol_id,
                    'usuario_id' => $usuario_id,
                    'registrado_por' => $currentUser
                ]);
            }
        }

        $db->commit();

        return getUsuario($db, $usuario_id);

    } catch (Throwable $e) {
        $db->rollBack();
        return ['success' => false, 'error' => $e->getMessage(), 'data' => null];
    }
}

/**
 * Save complete state (bulk update - used by JS frontend)
 */
function saveState(SqlEr $db, array $data): array
{
    $usuarios = $data['usuarios'] ?? [];
    $rol_usuario = $data['rol_usuario'] ?? [];

    $currentUser = $_SESSION['nick'] ?? 'system';
    $now = date('Y-m-d H:i:s');

    $db->beginTransaction();

    try {
        // Get existing user IDs
        $existingUsers = $db->query("SELECT usuario_id FROM usuario") ?: [];
        $existingIds = array_column($existingUsers, 'usuario_id');
        $incomingIds = array_column($usuarios, 'usuario_id');

        // Delete removed users
        $toDelete = array_diff($existingIds, $incomingIds);
        if (!empty($toDelete)) {
            $placeholders = implode(',', array_fill(0, count($toDelete), '?'));
            $db->execute("DELETE FROM usuario WHERE usuario_id IN ($placeholders)", array_values($toDelete));
        }

        // Upsert users
        foreach ($usuarios as $u) {
            $usuario_id = (int)($u['usuario_id'] ?? 0);

            $userData = [
                'nick' => $u['nick'] ?? '',
                'nombre' => $u['nombre'] ?? '',
                'email' => $u['email'] ?? '',
                'cel' => $u['cel'] ?? '',
                'estatus' => $u['estatus'] ?? 'Puede Login',
                'nota' => $u['nota'] ?? '',
                'password_forza_cambio' => $u['password_forza_cambio'] ?? 'No',
                'password_caducidad_dias' => (int)($u['password_caducidad_dias'] ?? 90),
                'ultimo_cambio_el' => $now,
                'ultimo_cambio_por' => $currentUser
            ];

            if (in_array($usuario_id, $existingIds, true)) {
                $db->update('usuario', $userData, 'usuario_id = ?', [$usuario_id]);
            } else {
                $userData['creado_el'] = $u['creado_el'] ?? $now;
                $userData['creado_por'] = $u['creado_por'] ?? $currentUser;
                $userData['password_ultimo_cambio'] = $u['password_ultimo_cambio'] ?? $now;
                $db->insert('usuario', $userData);
            }
        }

        // Rebuild rol_usuario relations
        $db->execute("DELETE FROM rol_usuario");

        foreach ($rol_usuario as $ru) {
            $db->insert('rol_usuario', [
                'rol_id' => (int)$ru['rol_id'],
                'usuario_id' => (int)$ru['usuario_id'],
                'registrado_por' => $currentUser
            ]);
        }

        $db->commit();

        return loadState($db);

    } catch (Throwable $e) {
        $db->rollBack();
        return ['success' => false, 'error' => $e->getMessage(), 'data' => null];
    }
}

/**
 * Delete user
 */
function deleteUsuario(SqlEr $db, int $id): array
{
    if ($id <= 0) {
        return ['success' => false, 'error' => 'ID de usuario inválido', 'data' => null];
    }

    $exists = $db->queryValue("SELECT usuario_id FROM usuario WHERE usuario_id = ?", [$id]);
    if (!$exists) {
        return ['success' => false, 'error' => 'Usuario no encontrado', 'data' => null];
    }

    $db->execute("DELETE FROM usuario WHERE usuario_id = ?", [$id]);

    return ['success' => true, 'error' => null, 'data' => null];
}
