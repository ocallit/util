<?php
/**
 * roles_api.php
 * API for managing roles (rol) and their user assignments (rol_usuario)
 */

declare(strict_types=1);

require_once __DIR__ . '/../config.php';

use Ocallit\SqlEr\SqlEr;

header('Content-Type: application/json; charset=utf-8');

try {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $action = $input['action'] ?? '';

    $db = SqlEr::getInstance();

    switch ($action) {
        case 'list':
            echo json_encode(listRoles($db));
            break;

        case 'get':
            $id = (int)($input['rol_id'] ?? 0);
            echo json_encode(getRol($db, $id));
            break;

        case 'save':
            echo json_encode(saveRol($db, $input));
            break;

        case 'delete':
            $id = (int)($input['rol_id'] ?? 0);
            echo json_encode(deleteRol($db, $id));
            break;

        case 'get_users':
            echo json_encode(getAvailableUsers($db));
            break;

        default:
            echo json_encode([
                'success' => false,
                'error' => 'Acción desconocida: ' . $action,
                'data' => null
            ]);
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'data' => null
    ]);
}

/**
 * List all roles with their users
 */
function listRoles(SqlEr $db): array
{
    $roles = $db->query("
        SELECT rol_id, rol, descripcion, registrado_el, registrado_por
        FROM rol
        ORDER BY rol
    ") ?: [];

    foreach ($roles as &$role) {
        $role['usuarios'] = $db->query("
            SELECT u.usuario_id, u.nick, u.nombre
            FROM usuario u
            INNER JOIN rol_usuario ru ON u.usuario_id = ru.usuario_id
            WHERE ru.rol_id = ?
            ORDER BY u.nick
        ", [$role['rol_id']]) ?: [];
    }
    unset($role);

    return ['success' => true, 'error' => null, 'data' => $roles];
}

/**
 * Get single role with users
 */
function getRol(SqlEr $db, int $id): array
{
    if ($id <= 0) {
        return ['success' => false, 'error' => 'ID de rol inválido', 'data' => null];
    }

    $rol = $db->queryRow("
        SELECT rol_id, rol, descripcion, registrado_el, registrado_por
        FROM rol
        WHERE rol_id = ?
    ", [$id]);

    if (!$rol) {
        return ['success' => false, 'error' => 'Rol no encontrado', 'data' => null];
    }

    $rol['usuarios'] = $db->query("
        SELECT u.usuario_id, u.nick, u.nombre
        FROM usuario u
        INNER JOIN rol_usuario ru ON u.usuario_id = ru.usuario_id
        WHERE ru.rol_id = ?
        ORDER BY u.nick
    ", [$id]) ?: [];

    return ['success' => true, 'error' => null, 'data' => $rol];
}

/**
 * Save (create or update) role with users
 */
function saveRol(SqlEr $db, array $input): array
{
    $rol_id = isset($input['rol_id']) ? (int)$input['rol_id'] : 0;
    $rol = trim($input['rol'] ?? '');
    $descripcion = trim($input['descripcion'] ?? '');
    $usuarios = $input['usuarios'] ?? [];

    if ($rol === '') {
        return ['success' => false, 'error' => 'El campo rol es obligatorio', 'data' => null];
    }

    $currentUser = $_SESSION['nick'] ?? 'system';

    $db->beginTransaction();

    try {
        if ($rol_id > 0) {
            // Update existing
            $db->update('rol', [
                'rol' => $rol,
                'descripcion' => $descripcion
            ], 'rol_id = ?', [$rol_id]);
        } else {
            // Insert new
            $db->insert('rol', [
                'rol' => $rol,
                'descripcion' => $descripcion,
                'registrado_por' => $currentUser
            ]);
            $rol_id = (int)$db->lastInsertId();
        }

        // Update user assignments
        $db->execute("DELETE FROM rol_usuario WHERE rol_id = ?", [$rol_id]);

        foreach ($usuarios as $u) {
            $usuario_id = is_array($u) ? (int)($u['usuario_id'] ?? 0) : (int)$u;
            if ($usuario_id > 0) {
                $db->insert('rol_usuario', [
                    'rol_id' => $rol_id,
                    'usuario_id' => $usuario_id,
                    'registrado_por' => $currentUser
                ]);
            }
        }

        $db->commit();

        return getRol($db, $rol_id);

    } catch (Throwable $e) {
        $db->rollBack();
        return ['success' => false, 'error' => $e->getMessage(), 'data' => null];
    }
}

/**
 * Delete role (rol_usuario cascades via FK)
 */
function deleteRol(SqlEr $db, int $id): array
{
    if ($id <= 0) {
        return ['success' => false, 'error' => 'ID de rol inválido', 'data' => null];
    }

    $exists = $db->queryValue("SELECT rol_id FROM rol WHERE rol_id = ?", [$id]);
    if (!$exists) {
        return ['success' => false, 'error' => 'Rol no encontrado', 'data' => null];
    }

    $db->execute("DELETE FROM rol WHERE rol_id = ?", [$id]);

    return ['success' => true, 'error' => null, 'data' => null];
}

/**
 * Get all available users for assignment
 */
function getAvailableUsers(SqlEr $db): array
{
    $usuarios = $db->query("
        SELECT usuario_id, nick, nombre
        FROM usuario
        WHERE estatus = 'Puede Login'
        ORDER BY nick
    ") ?: [];

    return ['success' => true, 'error' => null, 'data' => $usuarios];
}
